import os
import json
from os import listdir
from os.path import isfile, join

def openJson():
    onlyfiles = [f for f in listdir("D:\PhD_Projects\Demo2\subgraphCN")]
    JSON = []
    os.chdir("D:\Phd_Projects\Demo2\subgraphCN")
    for file in onlyfiles:
        with open(str(file), 'r') as out:
            j = json.loads(out.read())
            JSON.append(j)
    os.chdir("D:\Phd_Projects\Demo2")

    return JSON

def counter(Ofinal, Afinal, properties):
    hProp = {}
    for prp in properties:
        cO = 0
        cA = 0
        for t in Ofinal:
            if prp in t[0]:
                cO += 1
        for t in Afinal:
            if prp in t[0]:
                cA += 1
        hProp[prp] = cO + cA
    return hProp


def Remove(duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

def parserJson(jsonList):

    lPrpfinal = []
    hashList = []
    for js in jsonList:
        l = list(js.keys())
        obj = js[str(l[0])]
        action = js[str(l[1])]

        Obj1 = []
        propertyList = []
        for property in obj['N1']:
            propertyList.append(property)  ##take the properties
            for e in obj['N1'][property]:
                if e != []:
                    Obj1.append(([property], e))

        Act1 = []
        for property in action['N1']:
            for e in action['N1'][property]:
                if e != []:
                    Act1.append(([property, e]))

        obj.pop('N1')
        action.pop('N1')

        Obj2 = []
        for property in obj['N2']:
            for p in obj['N2'][property]:
                try:
                    for e in obj['N2'][property][p]:
                        if e != []:
                            Obj2.append(([property, p], e))
                except Exception:
                        continue
        Act2 = []
        for property in action['N2']:
            for p in action['N2'][property]:
                try:
                    for e in action['N2'][property][p]:
                        if e != []:
                            Act2.append(([property, p], e))
                except Exception:
                        continue
        obj.pop('N2')
        action.pop('N2')



        if len(obj) > 0:
            Obj3 = []
            for property in obj:
                for e in obj[property]:
                    if e[0] != []:
                        Obj3.append((e[1], e[0]))

            Act3 = []
            for property in action:
                for e in action[property]:
                    if e[0] != []:
                        Act3.append((e[1], e[0]))
            O = Obj1 + Obj2 + Obj3
            A = Act1 + Act2 + Act3
            O = Remove(O)
            A = Remove(A)
        else:
            O = Obj1 + Obj2
            A = Act1 + Act2
            O = Remove(O)
            A = Remove(A)

        Ofinal = []
        for p in O:
            if p[1] != str(l[0]):
                Ofinal.append(p)

        Afinal = []
        for p in A:
            if p[1] != str(l[1]):
                Afinal.append(p)

        hprp = counter(Ofinal, Afinal, propertyList)
        hashList.append(hprp)



    for pr in propertyList:
        c = 0
        for h in hashList:
            c = c + h[pr]
        lPrpfinal.append((pr, c))
    lPrpfinal = sorted(lPrpfinal, key=lambda x: x[1], reverse=True)
    lfinal = int(len(lPrpfinal) / 2)
    return lPrpfinal, lfinal



def importance(prpCount, lfinal):
    important = []
    for i in range(lfinal):
        important.append((prpCount[i][0], 2))

    notImportant = []
    for i in range(lfinal, len(prpCount)):
        notImportant.append((prpCount[i][0], 1))

    final = important + notImportant
    return final

if __name__ == "__main__":
    jsonList = openJson()
    prpCount, lfinal = parserJson(jsonList)
    prpFinal = importance(prpCount, lfinal)

    print(prpCount)
    print("\n")
    print(prpFinal)