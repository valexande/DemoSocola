import json
from nltk.corpus import wordnet as wn
import os

class mainParser():

    def __init__(self, json, object, action):
        self.json = json
        self.object = object
        self.action = action

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final



    def common(self):
        obj = self.json[str(self.object)]
        action = self.json[str(self.action)]

        O = []
        for n in obj:
            for t in obj[n]:
                if str(t[1]) != str(self.object):
                    O = O + [t[1]]

        O = self.Remove(O)

        A = []
        for n in action:
            for t in action[n]:
                if str(t[1]) != str(self.action):
                    A = A + [t[1]]
        A = self.Remove(A)

        lenOb = len(O)
        lenA = len(A)
        co1 = list(set(O).intersection(A))
        lenC = len(co1)
        value = lenC/(lenA + lenOb)

        flagCo = 0
        if value > 0.05:
            flagCo = 1

        print("common nodes similarity: " + str(value))

        return co1, O, A, lenC, value, flagCo, lenA + lenOb




    def wup(self):
        if len(wn.synsets(self.object)) > 0 and len(wn.synsets(self.action)) > 0:
            syn1 = wn.synsets(self.object)[0]
            syn2 = wn.synsets(self.action)[0]
            wUp = syn1.wup_similarity(syn2)
            print("WUP similarity: " + str(wUp))

            flagWUP = 0
            if wUp > 0.1:
                flagWUP = 1
            return wUp, flagWUP


    def path(self, C, totalLen):

        object = self.json[str(self.object)]
        action = self.json[str(self.action)]
        C = self.Remove(C)


        pathO = []
        for c in C:
            for n in object:
                for t in object[n]:
                    if c in t[1]:
                        pathO.append((t[0], c))
        pathO = self.Remove(pathO)

        pathA = []
        for c in C:
            for n in action:
                for t in action[n]:
                    if c in t[1]:
                        pathA.append((t[0], c))
        pathA = self.Remove(pathA)

        pO = []
        for o in pathO:
            for a in pathA:
                if o[1] == a[1]:
                    if isinstance(a[0], str) and isinstance(o[0], str):
                        t = [o[0]] + [a[0]]
                    elif isinstance(o[0], str):
                        t = [o[0]] + a[0]
                    elif isinstance(a[0], str):
                        t = o[0] + [a[0]]
                    else:
                        t = o[0] + a[0]
                    pO.append((t, o[1]))

        pA = []
        for a in pathA:
            for o in pathO:
                if a[1] == o[1]:
                    if isinstance(o[1], str) and isinstance(a[1], str):
                        t = [a[1]] + [o[1]]
                    elif isinstance(o[1], str):
                        t = a[1] + [o[1]]
                    elif isinstance(a[1], str):
                        t = [a[1]] + [o[1]]
                    else:
                        t = a[1] + o[1]
                    pA.append((t, a[1]))
        pA = self.Remove(pA)

        print("There are " + str(len(pO) + len(pA)) + " common paths in total")

        flagP = 0
        le = len(pO) + len(pA)
        if float(le/totalLen) > 0.1:
            flagP = 1

        return pO, pA, flagP


    def skeptical_credoulus(self, pO, pA):

        prpPattern = input()
        p1 = []
        for o in pO:
            if prpPattern in o[0]:
                p1.append(o)
        p2 = []
        for a in pA:
            if prpPattern in a[0]:
                p1.append(a)
        cre = p1 + p2
        print("There are " + str(len(cre)) + " paths with at least one occurrence of the property " + str(prpPattern) + " in it")

        p1 = []
        for o in pO:
            result = all(elem == o[0][0] for elem in o[0])
            if result:
                if prpPattern in o[0]:
                    p1.append(o)
        p2 = []
        for a in pA:
            result = all(elem == a[0][0] for elem in a[0])
            if result:
                if prpPattern in a[0]:
                    p2.append(a)

        ske = p1 + p2
        print("There are " + str(len(ske)) + " paths with all properties in it being " + str(prpPattern))

        return cre, ske

    def infer(self, flagCo, flagWUP, flagP, POS):

        similar = [flagCo, flagWUP, flagP]
        val = 0
        for s in similar:
            val = val + s

        if flagCo == 1:
            print(str(self.object).capitalize() + " " + str(self.action).capitalize() +
                  " graphs are consider similar with respect to how many common node they have")
        else:
            print(str(self.object).capitalize() + " " + str(self.action).capitalize() +
                  " graphs are NOT consider similar with respect to how many common node they have")

        if flagWUP == 1:
            print(str(self.object).capitalize() + " " + str(self.action).capitalize() +
                  " graphs are consider similar with respect to their WUP value")
        else:
            print(str(self.object).capitalize() + " " + str(self.action).capitalize() +
                  " graphs are NOT consider similar with respect to their WUP value")

        if flagP == 1:
            print(str(self.object).capitalize() + " " + str(self.action).capitalize() +
                  " graphs are consider similar with respect to how many common paths they have between them")
        else:
            print(str(self.object).capitalize() + " " + str(self.action).capitalize() +
                  " graphs are NOT consider similar with respect to how many common paths they between them")

        if val >= 2:
            print("The two graphs are related adequately")
            os.chdir("D:\PhD_Projects\Demo3\objects-actions")
            f = open("objPS.txt", "a")
            help = str(self.action) + ", " + str(self.object) + ", " + str(POS) + "\n"
            f.write(help)
            f.close()
        else:
            print("The two graphs are not related adequately")
