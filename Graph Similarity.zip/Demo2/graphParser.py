import json
from nltk.corpus import wordnet as wn

class mainParser():

    def __init__(self, json, object, action):
        self.json = json
        self.object = object
        self.action = action


    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def NestedDictValues(self, d):
        for v in d.values():
            if isinstance(v, dict):
                yield from self.NestedDictValues(v)
            else:
                yield v

    def NestedListValues(self, l):
        for v in l:
            if isinstance(v, list):
                yield from self.NestedListValues(v)
            else:
                yield v

    def common(self):

        object = self.json[str(self.object)]
        if len(object) <= 2:
            O = list(self.NestedDictValues(object))
            O = list(self.NestedListValues(O))
            O = self.Remove(O)
        else:
            O1 = list(self.NestedDictValues(object['N1']))
            O1 = list(self.NestedListValues(O1))
            O2 = list(self.NestedDictValues(object['N2']))
            O2 = list(self.NestedListValues(O2))
            o = object
            l = len(object)
            O3 = []
            k = 3
            for i in range(l - 2):
                t = "N" + str(k)
                for entity in object[t]:
                    O3.append(entity[0])
                k += 1
            O = O1 + O2 + O3
            O = self.Remove(O)

        action = self.json[str(self.action)]
        if len(action) <= 2:
            A = list(self.NestedDictValues(action))
            A = list(self.NestedListValues(A))
            A = self.Remove(A)
        else:
            A1 = list(self.NestedDictValues(action['N1']))
            A1 = list(self.NestedListValues(A1))
            A2 = list(self.NestedDictValues(action['N2']))
            A2 = list(self.NestedListValues(A2))
            l = len(action)
            A3 = []
            k = 3
            for i in range(l - 2):
                t = "N" + str(k)
                for entity in action[t]:
                    A3.append(entity[0])
                k += 1
            A = A1 + A2 + A3
            A = self.Remove(A)


        lenOb = len(O)
        lenA = len(A)
        co1 = list(set(O).intersection(A))
        lenC = len(co1)
        value = lenC/(lenA + lenOb)

        print("common nodes similarity: " + str(value))
        return co1, O, A, lenC, value,




    def wup(self):
        if len(wn.synsets(self.object)) > 0 and len(wn.synsets(self.action)) > 0:
            syn1 = wn.synsets(self.object)[0]
            syn2 = wn.synsets(self.action)[0]
            wUp = syn1.wup_similarity(syn2)
            print("WUP similarity: " + str(wUp))
            return wUp




    def path(self, C, lenC):

        object = self.json[str(self.object)]
        action = self.json[str(self.action)]
        C = self.Remove(C)
        pathObj1 = []
        for c in C:
            for property in object['N1']:
                if c in object['N1'][property]:
                    pathObj1.append(([property], c))

        pathAction1 = []
        for c in C:
            for property in action['N1']:
                if c in action['N1'][property]:
                    pathAction1.append(([property], c))

        object.pop('N1')
        action.pop('N1')

        pathObj2 = []
        for c in C:
            for property in object['N2']:
                for p in object['N2'][property]:
                    try:
                        for e in object['N2'][property][p]:
                            if c in e:
                                pathObj2.append(([property, p], c))
                    except Exception:
                        continue

        pathAction2 = []
        for c in C:
            for property in action['N2']:
                for p in action['N2'][property]:
                    try:
                        for e in object['N2'][property][p]:
                            if c in e:
                                pathAction2.append(([property, p], c))
                    except Exception:
                        continue

        object.pop('N2')
        action.pop('N2')


        if len(object) > 0:
            pathObj3 = []
            for c in C:
                for property in object:
                    for e in object[property]:
                        if c in e[0]:
                            pathObj3.append((e[1], c))

            pathAction3 = []
            for c in C:
                for property in action:
                    for e in action[property]:
                        if c in e[0]:
                            pathAction3.append((e[1], c))
            pathO = pathObj1 + pathObj2 + pathObj3
            pathA = pathAction1 + pathAction2 + pathAction3
            pathO = self.Remove(pathO)
            pathA = self.Remove(pathA)

        else:
            pathO = pathObj1 + pathObj2
            pathA = pathAction1 + pathAction2

            pathO = self.Remove(pathO)
            pathA = self.Remove(pathA)

        O = []
        for p in pathO:
            if p[1] != str(self.object):
                O.append(p)

        A = []
        for p in pathA:
            if p[1] != str(self.action):
                A.append(p)

        pO = []
        for o in O:
            for a in A:
                if o[1] == a[1]:
                    t = o[0] + a[0]
                    pO.append((t, o[1]))
        pO = self.Remove(pO)
        print("There are " + str(len(pO)) + " common paths from " + str(self.object) + " to " + str(self.action))

        pA = []
        for a in A:
            for o in O:
                if a[1] == o[1]:
                    t = a[1] + o[1]
                    pA.append((t, a[1]))
        pA = self.Remove(pA)
        print("There are " + str(len(pA)) + " common paths from " + str(self.action) + " to " + str(self.object))

        print("There are " + str(len(pO) + len(pA)) + " common paths in total")

        return pO, pA


    def skeptical_credoulus(self, pO, pA):

        prpPattern = input()
        p1 = []
        for o in pO:
            if prpPattern in o[0]:
                p1.append(o)
        p2 = []
        for a in pA:
            if prpPattern in a[0]:
                p1.append(a)
        cre = p1 + p2
        print("There are " + str(len(cre)) + " paths with at least one occurrence of the property " + str(prpPattern) + " in it")

        p1 = []
        for o in pO:
            result = all(elem == o[0][0] for elem in o[0])
            if result:
                if prpPattern in o[0]:
                    p1.append(o)
        p2 = []
        for a in pA:
            result = all(elem == a[0][0] for elem in a[0])
            if result:
                if prpPattern in a[0]:
                    p2.append(o)

        ske= p1 + p2
        print("There are " + str(len(ske)) + " paths with all properties in it being " + str(prpPattern))

        return cre, ske