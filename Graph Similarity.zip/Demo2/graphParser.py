import json
from nltk.corpus import wordnet as wn
import os

class mainParser():

    def __init__(self, json, object, action):
        self.json = json
        self.object = object
        self.action = action

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final


    def common(self):
        obj = self.json[str(self.object)]
        action = self.json[str(self.action)]

        O = []
        for n in obj:
            for t in obj[n]:
                if str(t[1]) != str(self.object):
                    O = O + [t[1]]

        O = self.Remove(O)

        A = []
        for n in action:
            for t in action[n]:
                if str(t[1]) != str(self.action):
                    A = A + [t[1]]
        A = self.Remove(A)

        lenOb = len(O)
        lenA = len(A)
        co1 = list(set(O).intersection(A))
        lenC = len(co1)
        value = lenC/(lenA + lenOb)

        print("\nCommon nodes similarity: " + str(value))

        return co1, O, A, lenC, value


    def wup(self):
        try:
            syn1 = wn.synsets(self.object)[0]
            syn2 = wn.synsets(self.action)[0]
            wUp = syn1.wup_similarity(syn2)
            print("WUP similarity: " + str(wUp))

            return wUp
        except Exception:
            return 0


    def path(self, C):

        object = self.json[str(self.object)]
        action = self.json[str(self.action)]
        C = self.Remove(C)


        pathO = []
        for c in C:
            for n in object:
                for t in object[n]:
                    if c == t[1]:
                        pathO.append((t[0], c))
        pathO = self.Remove(pathO)

        pathA = []
        for c in C:
            for n in action:
                for t in action[n]:
                    if c == t[1]:
                        pathA.append((t[0], c))
        pathA = self.Remove(pathA)

        pO = []
        for o in pathO:
            for a in pathA:
                if o[1] == a[1]:
                    if isinstance(a[0], str) and isinstance(o[0], str):
                        t = [o[0]] + [a[0]]
                    elif isinstance(o[0], str):
                        t = [o[0]] + a[0]
                    elif isinstance(a[0], str):
                        t = o[0] + [a[0]]
                    else:
                        t = o[0] + a[0]
                    pO.append((t, o[1]))
        pO = self.Remove(pO)

        pA = []
        for a in pathA:
            for o in pathO:
                if a[1] == o[1]:
                    if isinstance(o[1], str) and isinstance(a[1], str):
                        t = [a[1]] + [o[1]]
                    elif isinstance(o[1], str):
                        t = a[1] + [o[1]]
                    elif isinstance(a[1], str):
                        t = [a[1]] + [o[1]]
                    else:
                        t = a[1] + o[1]
                    pA.append((t, a[1]))
        pA = self.Remove(pA)

        le = len(pO) + len(pA)

        lO = 0
        for n in object:
            lO = lO + len(object[n])

        lA = 0
        for n in action:
            lA = lA + len(action[n])

        lTotal = lO + lA

        valuePath = float(le/lTotal)
        print("There are " + str(len(pO) + len(pA)) + " common paths in total, which is a percentage of the"
                                                      " total paths " + str(valuePath))


        return pO, pA, valuePath


    def infer(self, valueCommon, valueWUP, valuePath, POS):

        if valueWUP == None:
            valueWUP = 0.05##if none wordnet could not find one of the two words
            ##but is two strict to consider them zero, we use labels from the englidh language
            ##which were not found in a database

        weight = 2*valueWUP + 1.5*valuePath + valueCommon
        print(weight)
        if weight > 0.3:
            print("\nThe two graphs ARE related adequately")
            exit()
            os.chdir("D:\PhD_Projects\Demo3\objects-actions")
            f = open("objPS.txt", "a")
            help = str(self.action) + ", " + str(self.object) + ", " + str(POS) + "\n"
            f.write(help)
            f.close()
        else:
            print("\nThe two graphs are NOT adequately related")



    def skeptical_credoulus(self, pO, pA):##I dont know if we will keep this spec, with path based on property
        print("\n\nGive me property to search for paths")
        prpPattern = input()
        p1 = []
        for o in pO:
            if prpPattern in o[0]:
                p1.append(o)
        p2 = []
        for a in pA:
            if prpPattern in a[0]:
                p1.append(a)
        cre = p1 + p2
        print("There are " + str(len(cre)) + " paths with at least one occurrence of the property " + str(prpPattern) + " in it")

        p1 = []
        for o in pO:
            result = all(elem == o[0][0] for elem in o[0])
            if result:
                if prpPattern in o[0]:
                    p1.append(o)
        p2 = []
        for a in pA:
            result = all(elem == a[0][0] for elem in a[0])
            if result:
                if prpPattern in a[0]:
                    p2.append(a)

        ske = p1 + p2
        print("There are " + str(len(ske)) + " paths with all properties in it being " + str(prpPattern))

        return cre, ske


"""
Method I as shown in the summary gives slightly worse results than the one that exist
now in the code, with respect to correct and false examples. 

flagCo, flagWUP, flagP = 0, 0, 0
if valueCommon > 0.05:
    flagCo = 1
if valueWUP > 0.12:
    flagWUP = 1
if valuePath > 0.1:
    flagP = 1

if flagWUP == 1:
    print("\nThe two graphs ARE related adequately")
    exit()
    os.chdir("D:\PhD_Projects\Demo3\objects-actions")
    f = open("objPS.txt", "a")
    help = str(self.action) + ", " + str(self.object) + ", " + str(POS) + "\n"
    f.write(help)
    f.close()
elif flagWUP == 0 and flagP == 1:
    print("\nThe two graphs ARE related adequately")
    os.chdir("D:\PhD_Projects\Demo3\objects-actions")
    exit()
    f = open("objPS.txt", "a")
    help = str(self.action) + ", " + str(self.object) + ", " + str(POS) + "\n"
    f.write(help)
    f.close()
elif flagWUP == 0 and flagP == 0 and flagCo == 1:
    print("\nThe two graphs ARE related adequately")
    exit()
    os.chdir("D:\PhD_Projects\Demo3\objects-actions")
    f = open("objPS.txt", "a")
    help = str(self.action) + ", " + str(self.object) + ", " + str(POS) + "\n"
    f.write(help)
    f.close()
else:
    print("\nThe two paths are NOT adequately related")
"""