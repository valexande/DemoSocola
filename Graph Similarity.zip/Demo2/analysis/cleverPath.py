import os
import json
from os import listdir
from os.path import isfile, join

def openJson():
    onlyfiles = [f for f in listdir("D:/PhD_Projects/Demo2/analysis/objectActionCN")]
    JSON = []
    os.chdir("D:/Phd_Projects/Demo2/analysis/objectActionCN")
    for file in onlyfiles:
        with open(str(file), 'r') as out:
            j = json.loads(out.read())
            JSON.append(j)
    os.chdir("D:/Phd_Projects/Demo2/analysis")

    return JSON

def counter(Ofinal, Afinal, properties):
    hProp = {}
    for prp in properties:
        cO = 0
        cA = 0
        for t in Ofinal:
            if prp in t[0]:
                cO += 1
        for t in Afinal:
            if prp in t[0]:
                cA += 1
        hProp[prp] = cO + cA
    return hProp


def Remove(duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final


def counter(pO, pA):
    hashSingle = {}
    for o in pO:
        if hashSingle.get(str(o[0])) == None:
            hashSingle.setdefault(str(o[0]), []).append(str(o[1]))
        else:
            hashSingle[str(o[0])].append(str(o[1]))
    for a in pA:
        if hashSingle.get(str(a[0])) == None:
            hashSingle.setdefault(str(a[0]), []).append(str(a[1]))
        else:
            hashSingle[str(a[0])].append(str(a[1]))

    for pr in hashSingle:
        hashSingle[pr] = len(hashSingle[pr])

    return hashSingle

def parserJson(jsonList):

    listH = []
    for js in jsonList:
        O = {}
        A = {}

        l = list(js.keys())
        obj = js[str(l[0])]
        action = js[str(l[1])]

        Obj1 = []
        propertyList = []
        for property in obj['N1']:
            propertyList.append(property)  ##take the properties
            for e in obj['N1'][property]:
                if e != []:
                    Obj1.append(([property], e))

        Act1 = []
        for property in action['N1']:
            for e in action['N1'][property]:
                if e != []:
                    Act1.append(([property, e]))

        obj.pop('N1')
        action.pop('N1')

        Obj2 = []
        for property in obj['N2']:
            for p in obj['N2'][property]:
                try:
                    for e in obj['N2'][property][p]:
                        if e != []:
                            Obj2.append(([property, p], e))
                except Exception:
                        continue
        Act2 = []
        for property in action['N2']:
            for p in action['N2'][property]:
                try:
                    for e in action['N2'][property][p]:
                        if e != []:
                            Act2.append(([property, p], e))
                except Exception:
                        continue
        obj.pop('N2')
        action.pop('N2')
        O1 = []
        for o in Obj1:
            if e != str(l[0]):
                O1.append([o[0], o[1]])

        A1 = []
        for a in Act1:
            if e != str(l[1]):
               A1.append([[a[0]], a[1]])

        O2 = []
        for o in Obj2:
            for e in o[1]:
                if e != str(l[0]):
                    O2.append([o[0], e])

        A2 = []
        for a in Act2:
            for e in a[1]:
                if e != str(l[1]):
                    A2.append([a[0], e])

        O['N1'] = O1
        O['N2'] = O2
        A['N1'] = A1
        A['N2'] = A2

        Of = []
        for n in O:
            for t in O[n]:
                Of = Of + [t[1]]
        Of = Remove(Of)

        Af = []
        for n in A:
            for t in A[n]:
                Af = Af + [t[1]]
        Af = Remove(Af)

        C = list(set(Of).intersection(Af))
        C = Remove(C)

        pathO = []
        for c in C:
            for n in O:
                for t in O[n]:
                    if c == t[1]:
                        pathO.append((t[0], c))
        pathO = Remove(pathO)

        pathA = []
        for c in C:
            for n in A:
                for t in A[n]:
                    if c == t[1]:
                        pathA.append((t[0], c))
        pathA = Remove(pathA)

        pO = []
        for o in pathO:
            for a in pathA:
                if o[1] == a[1]:
                    if isinstance(a[0], str) and isinstance(o[0], str):
                        t = [o[0]] + [a[0]]
                        t = t[0] + t[1]
                    elif isinstance(o[0], str):
                        t = [o[0]] + a[0]
                        t = t[0] + t[1]
                    elif isinstance(a[0], str):
                        t = o[0] + [a[0]]
                        t = t[0] + t[1]
                    else:
                        t = o[0] + a[0]
                    pO.append((t, o[1]))
        pO = Remove(pO)

        pA = []
        for a in pathA:
            for o in pathO:
                if a[1] == o[1]:
                    if isinstance(o[1], str) and isinstance(a[1], str):
                        t = [a[0]] + [o[0]]
                        t = t[0] + t[1]
                    elif isinstance(o[1], str):
                        t = a[0] + [o[0]]
                        t = t[0] + t[1]
                    elif isinstance(a[1], str):
                        t = [a[0]] + [o[0]]
                        t = t[0] + t[1]
                    else:
                        t = a[0] + o[0]
                    pA.append((t, a[1]))
        pA = Remove(pA)


        preFinal = counter(pO, pA)
        listH.append(preFinal)

    hashFinal = {}
    for h in listH:
        for pr in h:
            if hashFinal.get(pr) == None:
                hashFinal.setdefault(pr, []).append(h[pr])
            else:
                hashFinal[pr].append(h[pr])

    for pr in hashFinal:
        k = 0
        for i in hashFinal[pr]:
            k = k + i
        hashFinal[pr] = k
    print(hashFinal)

    return hashFinal###sort it and export it!!!!! two small steps :)




if __name__ == "__main__":
    jsonList = openJson()
    print(len(jsonList))
    hashFinal = parserJson(jsonList)

