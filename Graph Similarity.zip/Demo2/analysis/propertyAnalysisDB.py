import os
import json
from os import listdir
from os.path import isfile, join

def openJson():
    onlyfiles = [f for f in listdir("D:\PhD_Projects\Demo2\subgraphDBpedia")]
    JSON = []
    os.chdir("D:\Phd_Projects\Demo2\subgraphDBpedia")
    for file in onlyfiles:
        with open(str(file), 'r') as out:
            j = json.loads(out.read())
            JSON.append(j)
    os.chdir("D:\Phd_Projects\Demo2")

    return JSON

def Remove(duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final


def counter(Ofinal, Afinal, properties):

    hProp = {}
    for prp in properties:
        cO = 0
        cA = 0
        for t in Ofinal:
            for ti in t:
                if prp in ti[0]:
                    cO += 1
        for t in Afinal:
            for ti in t:
                if prp in ti[0]:
                    cA += 1
        hProp[prp] = cO + cA
    return hProp



def parserJson(jsonList):

    lPrpfinal = []
    hashList = []
    prp = []
    for js in jsonList:
        l = list(js.keys())
        obj = js[str(l[0])]
        action = js[str(l[1])]

        O = []
        for n in obj:
            O.append(obj[n])


        A = []
        for n in action:
            A.append(action[n])

        propertyList = []
        for n in obj:
            for e in obj[n]:
                propertyList.append(e[0])

        for n in action:
            for e in action[n]:
                propertyList.append(e[0])

        propertyList = Remove(propertyList)
        propertyListFinal = []
        for l in propertyList:
            if isinstance(l, str):
                propertyListFinal.append(l)
            elif len(l) > 1:
                for li in l:
                    propertyListFinal.append(li)
        propertyListFinal = Remove(propertyListFinal)

        hprp = counter(O, A, propertyListFinal)

        hashList.append(hprp)
        prp = prp + propertyListFinal
    prp = Remove(prp)

    for p in prp:
        c = 0
        for h in hashList:
            try:
                c = c + h[p]
            except Exception:
                c = c + 0
        if c > 30:
            lPrpfinal.append((p, c))

    lPrpfinal = sorted(lPrpfinal, key=lambda x: x[1], reverse=True)
    lfinal = int(len(lPrpfinal) / 2)
    return lPrpfinal, lfinal

def importance(prpCount, lfinal):
    important = []
    for i in range(lfinal):
        important.append((prpCount[i][0], 2))

    notImportant = []
    for i in range(lfinal, len(prpCount)):
        notImportant.append((prpCount[i][0], 1))

    final = important + notImportant
    return final


if __name__ == "__main__":
    print("Compiling please wait...")
    jsonList = openJson()
    prpCount, lfinal = parserJson(jsonList)
    prpFinal = importance(prpCount, lfinal)

    print(prpCount)
    print("\n\n\n")
    print(len(prpCount))
    print("\n\n\n")
    print(prpFinal)