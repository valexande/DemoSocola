import os
import json
from os import listdir
from os.path import isfile, join
from graphParser import *

def findJson():
    onlyfiles = [f for f in listdir("D:\PhD_Projects\Demo2\subgraphContext") if isfile(join("D:\PhD_Projects\Demo2\subgraphContext", f))]
    print("Give me format: Object Action")
    choice = input()
    choice = choice.split(" ")
    help = ""
    for j in onlyfiles:
        if choice[0] in str(j) and choice[1].capitalize() in str(j):
            help = j

    if help != "":
        return help, choice
    else:
        return 0


def readJson(file):
    os.chdir("D:\Phd_Projects\Demo2\subgraphContext")
    with open(str(file), 'r') as out:
        j = json.loads(out.read())
        return j


if __name__ == "__main__":
    file, choice = findJson()
    js = readJson(file)
    parser = mainParser(js, choice[0], choice[1])
    C, objectList, actionList, lenC, valueCommon = parser.common()

    valueWUP = wupSimilarity = parser.wup()
    pO, pA, valuePath, lTotal = parser.path(C)

    valuePattern, choice[2] = parser.pathPattern(pO, pA, lTotal, choice[2])
    parser.infer(valueCommon, valueWUP, valuePath, valuePattern, choice[2])