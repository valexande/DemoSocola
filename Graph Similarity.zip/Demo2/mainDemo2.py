import os
import json
from dbPedia import *
from os import listdir
from os.path import isfile, join
from graphParser import *

def findJson():
    onlyfiles = [f for f in listdir("D:\PhD_Projects\Demo2\subgraph") if isfile(join("D:\PhD_Projects\Demo2\subgraph", f))]
    print("What object action should I search for?")
    print("Give me format: Object Action")
    choice = input()
    choice = choice.split(" ")
    help = ""
    for j in onlyfiles:
        if choice[0] in str(j) and choice[1].capitalize() in str(j):
            help = j

    if help != "":
        return help, choice
    else:
        return 0


def readJson(file):
    os.chdir("D:\Phd_Projects\Demo2\subgraph")
    with open(str(file), 'r') as out:
        j = json.loads(out.read())
        return j



if __name__ == "__main__":
    file, choice = findJson()
    json = readJson(file)
    parser = mainParser(json, choice[0], choice[1])
    C, lenO, lenA, lenC, valueCommons = parser.common()
    valueWUP = wupSimilarity = parser.wup()

    pO, pA = parser.path(C, lenC)
    pCre, pSke = parser.skeptical_credoulus(pO, pA)

    exit()


    wiki = mainDBpedia(choice[0], choice[1])
    tfScore = wiki.sparqlDBpedia()


