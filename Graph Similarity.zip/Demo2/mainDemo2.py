import os
import json
from dbPedia import *
from os import listdir
from os.path import isfile, join
from graphParser import *

def findJson():
    onlyfiles = [f for f in listdir("D:\PhD_Projects\Demo2\subgraphContextFalse") if isfile(join("D:\PhD_Projects\Demo2\subgraphContextFalse", f))]
    print("Give me format: Object Action")
    choice = input()
    choice = choice.split(" ")
    help = ""
    for j in onlyfiles:
        if choice[0] in str(j) and choice[1].capitalize() in str(j):
            help = j

    if help != "":
        return help, choice
    else:
        return 0


def readJson(file):
    os.chdir("D:\Phd_Projects\Demo2\subgraphContextFalse")
    with open(str(file), 'r') as out:
        j = json.loads(out.read())
        return j




if __name__ == "__main__":
    file, choice = findJson()
    js = readJson(file)
    parser = mainParser(js, choice[0], choice[1])
    C, objectList, actionList, lenC, valueCommon = parser.common()

    valueWUP = wupSimilarity = parser.wup()
    pO, pA, valuePath = parser.path(C)
    parser.infer(valueCommon, valueWUP, valuePath, choice[2])


""" 
def findJsonWiki(obj, action):
    onlyfiles = [f for f in listdir("D:\PhD_Projects\Demo2\subgraphDBpedia") if isfile(join("D:\PhD_Projects\Demo2\subgraphDBpedia", f))]
    help = ""
    for j in onlyfiles:
        if obj in str(j) and action.capitalize() in str(j):
            help = j

    if help != "":
        return help
    else:
        return 0

def readJsonWiki(fileWiki):
    os.chdir("D:\Phd_Projects\Demo2\subgraphDBpedia")
    with open(str(fileWiki), 'r') as outWiki:
        jWiki = json.loads(outWiki.read())
        return jWiki
        
        
    pCre, pSke = parser.skeptical_credoulus(pO, pA)  ##Give property search for paths

    fileWiki = findJsonWiki(choice[0], choice[1])##The values are small, to the point that no importance might exist
    jsonWiki = readJsonWiki(fileWiki)##Therefore, I think I will stick with CN graphs with the thresholds as mentioned
    wiki = mainDBpedia(jsonWiki, choice[0], choice[1])
    valueCommonWiki, CommonWiki = wiki.wikiCommon()
    valuePathWiki = wiki.wikiPath(CommonWiki)
"""