import os, json

class mainDBpedia():

    def __init__(self, json, obj, action):
        self.json = json
        self.obj = obj
        self.action = action

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final



    def wikiCommon(self):
        Object = self.json[str(self.obj)]
        Action = self.json[str(self.action)]

        O = []
        for n in Object:
            for t in Object[n]:
                if str(t[1]) != str(self.obj):
                    O = O + [t[1]]

        O = self.Remove(O)

        A = []
        for n in Action:
            for t in Action[n]:
                if str(t[1]) != str(self.action):
                    A = A + [t[1]]
        A = self.Remove(A)

        lenOb = len(O)
        lenA = len(A)
        co1 = list(set(O).intersection(A))
        lenC = len(co1)
        value = lenC/(lenA + lenOb)

        print("\nSimilarity based on common nodes over DBpedia graphs is:  " + str(value))


        return value, co1

    def wikiPath(self, C):##WUP similarity has no importance as it will give te same score twice we need to work only
        ##with common paths and similar nodes for path of them

        object = self.json[str(self.obj)]
        action = self.json[str(self.action)]
        C = self.Remove(C)


        pathO = []
        for c in C:
            for n in object:
                for t in object[n]:
                    if c == t[1]:
                        pathO.append((t[0], c))
        pathO = self.Remove(pathO)

        pathA = []
        for c in C:
            for n in action:
                for t in action[n]:
                    if c == t[1]:
                        pathA.append((t[0], c))
        pathA = self.Remove(pathA)

        pO = []
        for o in pathO:
            for a in pathA:
                if o[1] == a[1]:
                    if isinstance(a[0], str) and isinstance(o[0], str):
                        t = [o[0]] + [a[0]]
                    elif isinstance(o[0], str):
                        t = [o[0]] + a[0]
                    elif isinstance(a[0], str):
                        t = o[0] + [a[0]]
                    else:
                        t = o[0] + a[0]
                    pO.append((t, o[1]))
        pO = self.Remove(pO)

        pA = []
        for a in pathA:
            for o in pathO:
                if a[1] == o[1]:
                    if isinstance(o[1], str) and isinstance(a[1], str):
                        t = [a[1]] + [o[1]]
                    elif isinstance(o[1], str):
                        t = a[1] + [o[1]]
                    elif isinstance(a[1], str):
                        t = [a[1]] + [o[1]]
                    else:
                        t = a[1] + o[1]
                    pA.append((t, a[1]))
        pA = self.Remove(pA)

        le = len(pO) + len(pA)

        lO = 0
        for n in object:
            lO = lO + len(object[n])

        lA = 0
        for n in action:
            lA = lA + len(action[n])

        lTotal = lO + lA

        valuePathWiki = le/lTotal

        print("There are " + str(len(pO) + len(pA)) + " common paths in total over the DBpedia graphs, "
                                                      "which is a percentage of the total paths "
                                                      + str(float(valuePathWiki)))

        return valuePathWiki