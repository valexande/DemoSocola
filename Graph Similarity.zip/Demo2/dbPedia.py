import wikipedia
from SPARQLWrapper import SPARQLWrapper, JSON
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.stem.porter import PorterStemmer
from nltk.tokenize import word_tokenize
from sklearn.metrics.pairwise import cosine_similarity

class mainDBpedia():

    def __init__(self, object, action):
        self.object = object
        self.action = action

    def nlp(self, comObject, comAction):
        comObject = comObject.split("\n")
        helpO = ""
        for h in comObject:
            helpO = helpO + h + " "
        helpO = helpO.replace("=", "").replace("  ", " ").replace("   ", "")  ##Its on purpose 2 times
        helpO = helpO.replace("\'", "").replace("(", "").replace(")", "").replace("!", "").replace("%", "").replace(
            " – ", "")
        helpO = helpO.replace("*", "").replace("\"", "").replace("×", "").replace("&", "").replace("-", "").replace(
            ",", "").replace("\t", "")
        helpO = helpO.split(".")

        comAction = comAction.split("\n")
        helpA = ""
        for h in comAction:
            helpA = helpA + h + " "
        helpA = helpA.replace("=", "").replace("  ", " ").replace("   ", "")  ##Its on purpose 2 times
        helpA = helpA.replace("\'", "").replace("(", "").replace(")", "").replace("!", "").replace("%", "").replace(
            " – ", "")
        helpA = helpA.replace("*", "").replace("\"", "").replace("×", "").replace("&", "").replace("-", "").replace(
            ",", "").replace("\t", "")
        helpA = helpA.split(".")

        O = ""
        for h in helpO:
            O = O + h
        A = ""
        for h in helpA:
            A = A + h

        return O, A

    def tokenize(self, text):
        tokens = word_tokenize(text)
        stems = []
        for item in tokens: stems.append(PorterStemmer().stem(item))
        return stems


    def tfidf(self, O, A):

        text = [O]
        result = 0
        text.append(A)
        text_helper = [" ".join(self.tokenize(txt.lower())) for txt in text]
        vectorizer_common = TfidfVectorizer()
        matrix_common = vectorizer_common.fit_transform(text_helper).todense()
        result = cosine_similarity(matrix_common[0], matrix_common[1])

        return result[0][0]





    def sparqlDBpedia(self):
        comObject, comAction = "", ""
        obj = wikipedia.search(self.object)
        if len(obj) > 0:
            try:
                comObject = wikipedia.page(obj[0].lower()).content
            except Exception as e:
                sparql_perceived = SPARQLWrapper("http://dbpedia.org/sparql")
                sparql_perceived.setQuery(""" PREFIX dbpedia-owl: <http://dbpedia.org/ontology/>
                                    SELECT DISTINCT ?comment WHERE{
                                    ?entry rdfs:label \"""" + str(obj[0]) + """\"@en. 
                                    ?entry dbpedia-owl:abstract ?comment
                                    FILTER(lang (?comment) = 'en')}
                                """)
                sparql_perceived.setReturnFormat(JSON)
                results_perceived = sparql_perceived.query().convert()
                results_perceived = results_perceived['results']['bindings']
                comObject = results_perceived[0]['comment']['value']
        else:
            pass

        action = wikipedia.search(self.action)
        if len(action) > 0:
            try:
                comAction = wikipedia.page(action[0].lower()).content
            except Exception as e:
                sparql_perceived = SPARQLWrapper("http://dbpedia.org/sparql")
                sparql_perceived.setQuery(""" PREFIX dbpedia-owl: <http://dbpedia.org/ontology/>
                                    SELECT DISTINCT ?comment WHERE{
                                    ?entry rdfs:label \"""" + str(action[0]) + """\"@en. 
                                    ?entry dbpedia-owl:abstract ?comment
                                    FILTER(lang (?comment) = 'en')}
                                """)
                sparql_perceived.setReturnFormat(JSON)
                results_perceived = sparql_perceived.query().convert()
                results_perceived = results_perceived['results']['bindings']
                comAction = results_perceived[0]['comment']['value']
        else:
            pass



        if comAction != "" and comObject != "":
            comObject, comAction = self.nlp(comObject, comAction)##nlp cleaning of text
            score = self.tfidf(comObject, comAction)##tf idf score
            print("dbpedia similarity is: " + str(score))
            return score
        else:
            return 0