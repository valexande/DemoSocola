import os, json
import nltk
from nltk.corpus import wordnet as wn

class mainDBpedia():

    def __init__(self, object, action, oList, aList):
        self.object = object
        self.action = action
        self.oList = oList
        self.aList = aList

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def readJson(self, file):
        os.chdir("D:\PhD_Projects\Demo2\subgraphDBpedia")
        with open(str(file), 'r') as out:
            j = json.loads(out.read())
            return j


    def wikiJson(self):
        name = str(self.object) + str(self.action) + "wiki.json"
        js = self.readJson(name)
        Object = js[str(self.object)]
        Action = js[str(self.action)]

        objectDBpedia = []
        for o in self.oList:
            for property in Object:
                for e in Object[property]:
                    if o in e:
                        objectDBpedia.append(o)

        actionDBpedia = []
        for a in self.action:
            for property in Action:
                for e in Action[property]:
                    if a in e:
                        actionDBpedia.append(o)

        objectDBpedia = self.Remove(objectDBpedia)
        actionDBpedia = self.Remove(actionDBpedia)

        objDBpedia = []
        for o in objectDBpedia:
            w = wn.synsets(o)
            if len(w) > 0:
                objDBpedia.append(o)

        actDBpedia = []
        for a in actionDBpedia:
            w = wn.synsets(a)
            if len(w) > 0:
                actDBpedia.append(a)

        print("The common nodes in CN and DBpedia for " + str(self.object) + " are " + str(objectDBpedia))
        print("The common nodes in CN and DBpedia for " + str(self.action) + " are " + str(actionDBpedia))
        return objectDBpedia, actionDBpedia