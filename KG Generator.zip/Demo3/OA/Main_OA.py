from objectClass import *
from actionClass import *
from process import *
from importance import *
import os

data = processData()

image = data.processImage()

data.processLabelInstances(image)

os.chdir("D:/PhD_Projects/ULO_Generator/Classification_Uncertainty_Characteristics")
exec(open("CUC.py").read())


objectHierarchy()


data.processAction()
actionHierarchy()



data.processPartOf(image)
os.chdir("D:/PhD_Projects/ULO_Generator/Classification_Uncertainty_Characteristics")
exec(open("CUC.py").read())


data.processCharacteristics()
os.chdir("D:/PhD_Projects/ULO_Generator/Classification_Uncertainty_Characteristics")
exec(open("CUC.py").read())


data.proccessSpatial(image)
os.chdir("D:/PhD_Projects/ULO_Generator/SpatialRelations")
exec(open("SpatialQueries.py").read())

data.leftOvers(image)

print("Finito")



"""
## It may not be needed after the new classes and properties that I Have defined
os.chdir("D:/PhD_Projects/ULO_Generator/OA")
imp = importanceData()
imp.duplicates()
"""
