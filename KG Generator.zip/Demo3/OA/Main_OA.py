from objectClassification import *
from actionClassification import *
from objPurposeState import *


if __name__=="__main__":
    obj = objectHierarchy()
    flagObj = obj.classObject()
    action = actionHierarchy()
    flagAction = action.classAction()
    perPSC = objPS()


    if flagAction == 1 and flagObj == 1:
        flagPerform = perPSC.performRelation()

    if flagAction == 1 and flagObj == 1:
        flagState = perPSC.stateRelation()