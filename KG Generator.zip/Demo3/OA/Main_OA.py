from objectClassification import *
from actionClassification import *

if __name__=="__main__":
    obj = objectHierarchy()
    flagObj = obj.classObject()
    #actionHierarchy()

