import os
from rdflib import Graph

class objectCanPerform():
    os.chdir('D:/PhD_Projects/ULO_Generator/objects-actions')

    def Remove(duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    f = open("objectPurpose.txt")
    listPurpose = []
    for line in f.readlines():
        listPurpose.append(line.replace("\n", "").split(", "))
    f.close()

    g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
    help = ""
    for purpose in listPurpose:
        if purpose[1] == "performed":
            help = ":" + str(purpose[0]).capitalize() + " :performedBy :" + str(purpose[2]).capitalize() + ".\n "
        g.write(help)
    g.close()

    g = Graph()
    g.parse("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", format="n3")
    result = list(g.query("SELECT DISTINCT ?y ?z WHERE{?x rdfs:subClassOf :Action. ?y rdfs:subClassOf ?x. ?z rdfs:subClassOf ?y}"))
    Action = []
    for res in result:
        Action.append(res[0].split("#")[1])
        Action.append(res[1].split("#")[1])


    t = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
    for purpose in listPurpose:
        help = ""
        if purpose[1].capitalize() in Action:
            help = ":" + str(purpose[1]).capitalize() + " :performedBy :" + str(purpose[0]).capitalize() + ".\n "
            help1 = ":" + str(purpose[1]).capitalize() + " :affects :" + str(purpose[2]).capitalize() + ".\n"
            t.write(help + help1)
    t.close()