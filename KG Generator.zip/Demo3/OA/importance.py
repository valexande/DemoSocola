import os



class importanceData():

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def duplicates(self):

        os.chdir("D:/PhD_Projects/ULO_Generator/objects-actions")
        f = open("examplePhilippos.txt", "r")

        predicate = []
        label = []
        for line in f.readlines():
            if 'pred_rels' in line:
                line = line.replace("\n", "").split(": (")[1].replace("\'", "").split("); score: ")
                line = line[0].split(", ")
                predicate.append(line)
            elif 'pred_labels ' in line:
                line = line.replace("\n", "").split(" ")
                Object = line[2].replace(";", "").split("-")
                Object = Object[1] + Object[0]
                ObjectClass = ''.join([i for i in Object if not i.isdigit()])
                label.append([Object, "isA", ObjectClass.capitalize()])
            else:
                pass





        labelFinal = []
        for lab in label:
            k = 0
            for lab0 in label:
                if lab == lab0:
                    k += 1
            if k > 1:
                labelFinal.append((lab, k))

        predicateFinal = []
        for pre in predicate:
            k = 0
            for pre0 in predicate:
                if pre == pre0:
                    k += 1
            if k > 1:
                predicateFinal.append((pre, k))

        labelFinal = self.Remove(labelFinal)
        predicateFinal = self.Remove(predicateFinal)

        print("Cardinality of Objects:\n" + str(labelFinal))
        print("\n\n\n")
        print("Cardinality of Properties:\n" + str(predicateFinal))