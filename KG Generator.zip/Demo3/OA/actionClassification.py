from nltk.corpus import wordnet as wn
import os

class actionHierarchy():

    def __init__(self):
        pass

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final


    def classAction(self):
        os.chdir('D:/PhD_Projects/Demo3/objects-actions')

        files = open("ActionClass.txt", "r")
        Paths = []
        k = 0
        for f in files.readlines():
            entity = f.replace("\n", "").replace("_", " ").replace("-", " ").replace(" of ", " ").replace(" for ", " "). \
                replace(" Sliced", "").lower()
            if entity == "text":
                entity = "type"
            wordNet = wn.synsets(entity, wn.VERB)
            if wordNet == []:
                entity = list(entity.split(" "))
                if len(entity) > 2:
                    entity = entity[2]
                    wordNet = wn.synsets(entity, wn.VERB)
                elif len(entity) == 2:
                    entity = entity[0]
                    wordNet = wn.synsets(entity, wn.VERB)
                else:
                    entity = entity[0]
                    wordNet = wn.synsets(entity, wn.VERB)
                if wordNet == []:
                    pathRoot = [entity, 'other']
                else:
                    depth = min([len(path) for path in wordNet[0].hypernym_paths()])
                    pathRoot = []
                    wordNet = wordNet[0]
                    while depth > 1:
                        filter = wordNet.hypernyms()
                        wordNet = filter[0]
                        depth = depth - 1
                        pathRoot.append(filter[0].name())
            else:
                depth = min([len(path) for path in wordNet[0].hypernym_paths()])
                pathRoot = []
                wordNet = wordNet[0]
                while depth > 1:
                    filter = wordNet.hypernyms()
                    wordNet = filter[0]
                    depth = depth - 1
                    pathRoot.append(filter[0].name())
            if pathRoot == []:
                pathRoot = [entity, 'other']
            pathRoot = [entity] + pathRoot
            pathRootNew = []
            for node in pathRoot[0:]:
                node = node.replace(".n.", "").replace(".v.", "").replace("\t", "")
                node = ''.join([i for i in node if not i.isdigit()])
                pathRootNew.append(node)
            pathRootNew = self.Remove(pathRootNew)
            Paths.append(pathRootNew)
        files.close()

        f = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
        for root in Paths:
            root = self.Remove(root)
            length = len(root)
            if "action" in root:
                i = int(root.index("action"))
                root[i] = str(root[i]) + "s"
            if "object" in root:
                i = int(root.index("objects"))
                root[i] = str(root[i]) + "s"
            if "room" in root:
                i = int(root.index("room"))
                root[i] = str(root[i]) + "s"
            if "state" in root:
                i = int(root.index("state"))
                root[i] = str(root[i]) + "s"
            if "handle" in root:
                i = int(root.index("handle"))
                root[i] = str(root[i]) + "s"
            if "classification" in root:
                i = int(root.index("classification"))
                root = root[:int(i)]

            if length == 1:
                f.write(
                    ":" + str(root[0].capitalize().replace(" ", "_")) + " rdfs:subClassOf :Action; rdf:type owl:Class .\n")

            else:

                f.write(":" + str(root[0].capitalize().replace(" ", "_")) + " rdfs:subClassOf :" + str(
                    root[1].capitalize().replace(" ", "_")) + "; rdf:type owl:Class .\t"
                                                              ":" + str(
                    root[1].capitalize().replace(" ", "_")) + " rdfs:subClassOf :Action; rdf:type owl:Class .\n")
        f.close()

        return 1