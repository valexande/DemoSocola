import os
from rdflib import Graph

class processData():

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def processImage(self):
        f = open("examplePhilippos.txt", "r")
        g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
        image = ""
        for line in f.readlines():
            if "image" in line:
                help = " :" + str(line.replace("\n", "")) + " rdf:type :Image.\n"
                g.write(help)
                image = str(line.replace("\n", ""))
        g.close()
        f.close()
        return image

    def processLabelInstances(self, image):
        os.chdir("D:/PhD_Projects/ULO_Generator/objects-actions")
        f = open("objects5.txt", "w")
        f.write("")
        f.close()
        f = open("examplePhilippos.txt", "r")
        labelList = []
        for line in f.readlines():
            help = line.replace("\n", "").replace("(", "").replace(")", "").replace("\'", "").replace(",", "").replace(";", "").split(" ")
            if help[0] == 'pred_labels':
                labelList.append((help[2], help[4]))
        f.close()

        label = []
        for line in labelList:
            line = line[0].replace("-", "")
            line = ''.join([i for i in line if not i.isdigit()])
            label.append(line)

        label = self.Remove(label)


        g = open("objects5.txt", "a")
        for line in label:
            g.write(str(line) + "\n")
        g.close()
        os.chdir("D:/PhD_Projects/ULO_Generator/Classification_Uncertainty_Characteristics")
        f = open("cucTest.txt", "w")
        f.write("")
        f.close()


        g = open("cucTest.txt", "a")
        for line in labelList:
            uncertainty = line[1]
            lineHelp = line[0].replace("-", "")
            line = line[0].split("-")
            line = str(line[1]) + str(line[0])
            lineHelp = ''.join([i for i in lineHelp if not i.isdigit()])
            help = str(line).replace("-", "") + ", isA, " + str(lineHelp).capitalize() + ", " + str(uncertainty) +", " + str(image) + "\n"
            g.write(help)
        g.close()

        g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
        for line in labelList:
            help = ":" + str(line[0]) + " :hasCharacteristic :characteristic_" + str(line[0]) + ".\n"
            help0 = ":characteristic_" + str(line[0]) + " rdf:type :Characteristic.\n"
            g.write(help + help0)
        g.close()

        return 0



    def processPartOf(self, image):
        os.chdir("D:/PhD_Projects/ULO_Generator/objects-actions")
        f = open("examplePhilippos.txt", "r")
        propertyList = []
        for line in f.readlines():
            help = line.replace("\n", "").replace("(", "").replace(")", "").replace("\'", "").replace(",", "").replace(";", "").split(" ")
            if help[0] == 'pred_rels':
                propertyList.append([help[2], help[3], help[4], help[6]])
        f.close()

        os.chdir("D:/PhD_Projects/ULO_Generator/Classification_Uncertainty_Characteristics")
        f = open("cucTest.txt", "w")
        f.write("")
        f.close()

        f = open("cucTest.txt", "a")
        for line in propertyList:
            if line[1] == "has":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", part, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
        f.close()

        return 0

    def proccessSpatial(self, image):
        os.chdir("D:/PhD_Projects/ULO_Generator/objects-actions")
        f = open("examplePhilippos.txt", "r")
        propertyList = []
        for line in f.readlines():
            help = line.replace("\n", "").replace("(", "").replace(")", "").replace("\'", "").replace(",", "").replace(
                ";", "").replace("in front of", "in_front_of").replace("next to", "next_to").replace("right of", "right_of").\
                replace("left of", "left_of").replace("attached to", "attached_to").replace("standing on", "standing_on").split(" ")

            if help[0] == 'pred_rels':
                propertyList.append([help[2], help[3], help[4], help[6]])
        f.close()


        os.chdir("D:/PhD_Projects/ULO_Generator/SpatialRelations")
        f = open("spatialTest.txt", "w")
        f.write("")
        f.close()

        f = open("spatialTest.txt", "w")
        for line in propertyList:
            if line[1] == "under":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", under, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"

                f.write(help)
            elif line[1] == "near":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", near, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "next_to":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", next to, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "right_of":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", right of, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "left_of":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", left of, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "above":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", above, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "behind":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", behind, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "in":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", in, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "on":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", on, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "in_front_of":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", front of, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "across":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", across, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "against":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", against, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "along":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", along, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "at":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", at, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "attached_to":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", attached_to, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "behind":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", behind, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "between":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", between, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "standing_on":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", standing on, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            elif line[1] == "with":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                bObject = line[2].split("-")
                bObject = str(bObject[1]) + str(bObject[0])
                help = str(aObject) + ", with, " + str(bObject) + ", " + str(line[3]) + ", " + str(image) + "\n"
                f.write(help)
            else:
                pass
        f.close()

        return 0

    def processCharacteristics(self):
        os.chdir("D:/PhD_Projects/ULO_Generator/objects-actions")

        f = open("examplePhilippos.txt", "r")
        labelList = []
        for line in f.readlines():
            help = line.replace("\n", "").replace("(", "").replace(")", "").replace("\'", "").replace(",", "").replace(
                ";", "").split(" ")
            if help[0] == 'pred_rels':
                labelList.append([help[2], help[3], help[4], help[6]])
        f.close()

        os.chdir("D:/PhD_Projects/ULO_Generator/Classification_Uncertainty_Characteristics")
        f = open("cucTest.txt", "w")
        f.write("")
        f.close()
        f = open("cucTest.txt", "a")
        for line in labelList:
            if line[1] == "material":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                help = str(aObject) + ", material, " + str(line[2]) +", " + str(line[3]) + "\n"
                f.write(help)
            elif line[1] == "shape":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                help = str(aObject) + ", shape, " + str(line[2]) +", " + str(line[3]) + "\n"
                f.write(help)
            elif line[1] == "color":
                aObject = line[0].split("-")
                aObject = str(aObject[1]) + str(aObject[0])
                help = str(aObject) + ", color, " + str(line[2]) + ", " + str(line[3]) + "\n"
                f.write(help)
            else:
                pass

        f.close()

    def processAction(self):
        os.chdir("D:/PhD_Projects/ULO_Generator/objects-actions")

        f = open("examplePhilippos.txt", "r")
        labelList = []
        for line in f.readlines():
            help = line.replace("\n", "").replace("(", "").replace(")", "").replace("\'", "").replace(",", "").replace(
                ";", "").split(" ")
            if help[0] == 'pred_labels-action':
                labelList.append(help[2])
        f.close()

        f = open("ActionTest.txt", "w")
        f.write("")
        f.close()

        f = open("ActionTest.txt", "a")
        for line in labelList:
            f.write(line + "\n")
        f.close()



    def leftOvers(self, image):
        os.chdir("D:/PhD_Projects/ULO_Generator/objects-actions")


        f = open("examplePhilippos.txt", "r")
        tripletsList = []
        for line in f.readlines():
            if 'pred_rels' in line:
                line = line.replace("\n", "").split(": (")[1].replace("\'", "").split("); score: ")
                line = (line[0].split(", "), line[1])
                if line[0][1] != 'has' and line[0][1] != 'in front of' and line[0][1] != 'above':
                    tripletsList.append(line)
        f.close()

        for line in tripletsList:
            aObject = line[0][0].split("-")
            if len(aObject) > 1:
                aObject = str(aObject[1]) + str(aObject[0])
            bObject = line[0][2].split("-")
            if len(bObject) > 1:
                bObject = str(bObject[1]) + str(bObject[0])
            line[0][0] = aObject
            line[0][2] = bObject

            help = line[0][1].split(" ")
            t = ""
            for word in help:
                t = t + word.capitalize()
            line[0][1] = "is" + t

        g = Graph()
        g.parse("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", format="n3")
        result1 = list(g.query("SELECT DISTINCT ?object WHERE { ?subject rdfs:subClassOf :Object . ?subj rdfs:subClassOf ?subject . ?object rdf:type ?subj}"))
        result0 = list(g.query("SELECT DISTINCT ?object WHERE {  ?subject rdfs:subClassOf :Object .  ?subj rdfs:subClassOf ?subject .  ?sub rdfs:subClassOf ?subj. ?object rdf:type ?sub.}"))

        Action = ['isAboveOf', 'isAcrossOf', 'isAgainstOf', 'isAlongOf', 'isAt', 'isAttachedTo', 'isBehind', 'isBetween', 'isFrontOf'
                  'isIn', 'isLeftof', 'isNear', 'isNextTo', 'isOn', 'isPartOf', 'isRightOf', 'isStandingOn', 'isUnder', 'isWith']


        result1 = result1 + result0
        Object = []
        for res in result1:
            Object.append(res[0].split("#")[1])


        finalTriplet = []
        for triplet in tripletsList:
            if triplet[0][1] not in Action:
                if triplet[0][0] in Object and triplet[0][2] in Object:
                    finalTriplet.append(triplet)

        Property = []
        for property in finalTriplet:
            Property.append(property[0][1])

        Property = self.Remove(Property)
        t = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
        help = ""
        for property in Property:
            help = ":" + str(property) + " rdf:type owl:ObjectProperty ; rdfs:domain :Object; rdfs:range :Object .\n"
            t.write(help)
        t.close()

        t = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
        for triplet in finalTriplet:
            help = ":" + str(triplet[0][0]) + " :" + str(triplet[0][1]) + " :" + str(triplet[0][2]) + ".\n"
            tri = str(triplet[0][1]).replace(" ", "")
            help1 = ":certainty" + str(triplet[0][0]).capitalize() + tri + str(triplet[0][2]).capitalize() + " rdf:type :Certainty.\n"
            help2 = ":certainty" + str(triplet[0][0]).capitalize() + tri + str(triplet[0][2]).capitalize() + " :listOfObject (:" + str(triplet[0][0]) + " :" + str(triplet[0][2]) + ");\n"
            help3 = ":certaintyValue \"" + str(triplet[1]) + "\"^^xsd:double;\n"
            help4 = ":inImage :" + str(image) + ".\n"
            t.write(help + help1 + help2 + help3 + help4)


        t.close()
