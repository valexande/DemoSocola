from nltk.corpus import wordnet as wn
import os

class objectHierarchy():
    os.chdir('D:/PhD_Projects/ULO_Generator/objects-actions')

    def Remove(duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    files = open("objects5.txt", "r")
    Paths = []
    k = 0
    listEntity = []
    for f in files.readlines():
        entity = f.replace("\n", "").replace("_", " ").replace("-", " ").replace(" of ", " ").replace(" for ", " "). \
            replace(" Sliced", "").lower()

        listEntity.append(entity)

        entity = list(entity.split(" "))
        if len(entity) > 2:
            entity = entity[2].capitalize()
            wordNet = wn.synsets(entity, wn.NOUN)
        elif len(entity) == 2:
            entity = entity[1].capitalize()
            wordNet = wn.synsets(entity, wn.NOUN)
        else:
            entity = entity[0].capitalize()
            wordNet = wn.synsets(entity, wn.NOUN)

        if wordNet == []:
            pathRoot = [entity, 'other']
        else:
            depth = min([len(path) for path in wordNet[0].hypernym_paths()])
            pathRoot = []
            wordNet = wordNet[0]
            while depth > 1:
                filter = wordNet.hypernyms()
                wordNet = filter[0]
                depth = depth - 1
                pathRoot.append(filter[0].name())

        pathRootNew = []
        for node in pathRoot[0:]:
            node = node.replace(".n.", "").replace(".v.", "").replace("\t", "")
            node = ''.join([i for i in node if not i.isdigit()])
            pathRootNew.append(node)
        pathRootNew = [entity.replace("\t", "")] + pathRootNew
        pathRootNew = Remove(pathRootNew)
        Paths.append(pathRootNew)
    files.close()



    f = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
    t = 0
    for root in Paths:
        root = Remove(root)
        if "action" in root:
            i = int(root.index("action"))
            root = root[:int(i)]
        if "object" in root:
            i = int(root.index("object"))
            root = root[:int(i)]
        if "measure" in root:
            i = int(root.index("measure"))
            root = root[:int(i)]
        if "room" in root:
            i = int(root.index("room"))
            root = root[:int(i)]
        if "state" in root:
            i = int(root.index("state"))
            root = root[:int(i)]
        if "part" in root:
            i = int(root.index("part"))
            root = root[:int(i)]
        if "uncertainty" in root:
            i = int(root.index("uncertainty"))
            root = root[:int(i)]
        if "classification" in root:
            i = int(root.index("classification"))
            root = root[:int(i)]
        length = len(root)

        if length == 1:
            f.write(":" + str(listEntity[t].capitalize().replace(" ", "_").replace("'s",
                                                                             "")) + " rdfs:subClassOf :Object; rdf:type owl:Class  .\n")
        elif length == 2:
            f.write(":" + str(listEntity[t].capitalize().replace(" ", "_").replace("'s", "")) + " rdfs:subClassOf :" + str(
                root[1].capitalize().replace(" ", "_").replace("'s", "")) + "; rdf:type owl:Class  .\t"
                                                                            ":" + str(
                root[1].capitalize().replace(" ", "_").replace("'s",
                                                               "")) + " rdfs:subClassOf :Object; rdf:type owl:Class  .\n")
        else:
            Hierarchy = ""
            k = 0


            if listEntity[t].capitalize().replace(" ", "_").replace("'s", "") == root[0].capitalize().replace(" ", "_").replace("'s", ""):
                root.pop(0)
                root = [listEntity[t]] + root
                help = ""

            else:
                help = ":" + str(listEntity[t]).capitalize().replace(" ", "_").replace("'s", "") + \
                       " rdfs:subClassOf :" + str(root[0]).capitalize().replace(" ", "_").replace("'s",
                                                                                                  "") + "; rdf:type owl:Class  .\t"

            for i in range(2):
                Hierarchy = Hierarchy + ":" + str(
                    root[i].capitalize().replace(" ", "_").replace("'s", "")) + " rdfs:subClassOf :" + str(
                    root[i + 1].capitalize().replace(" ", "_").replace("'s", "")) + "; rdf:type owl:Class  .\t"
                k = k + 1
            f.write(help + Hierarchy + ":" + str(root[k].capitalize().replace(" ", "_").replace("'s",
                                                                                         "")) + " rdfs:subClassOf :Object; rdf:type owl:Class  .\n")
        t = t + 1
    f.close()