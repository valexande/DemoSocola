import os
from nltk.corpus import wordnet as wn

class objPS():

    def __init__(self):
        pass

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def performRelation(self):
        os.chdir('D:/PhD_Projects/Demo3/objects-actions')

        f = open("objPS.txt", "r")
        listPurpose = []
        for line in f.readlines():
            listPurpose.append(line.replace("\n", "").split(", "))
        f.close()

        g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
        help = ""
        for purpose in listPurpose:
            if purpose[2] == "OA":
                help = ":" + str(purpose[0]).capitalize() + " :performedBy :" + str(purpose[1]).capitalize() + ".\n "
                g.write(help)
        g.close()

        return 1

    def stateRelation(self):
        os.chdir('D:/PhD_Projects/Demo3/objects-actions')

        f = open("objPS.txt", "r")
        listState = []
        for line in f.readlines():
            listState.append(line.replace("\n", "").split(", "))
        f.close()

        g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
        for state in listState:
            if state[2] == "S":
                help = ":" + str(state[1]).capitalize() + " :inState :" + str(state[0]).capitalize() + ".\n"
                g.write(help)

        return 1


    def characteristic(self):
        os.chdir('D:/PhD_Projects/Demo3/objects-actions')

        f = open("objPS.txt", "r")
        listChar = []
        for line in f.readlines():
            char = line.replace("\n", "").split(", ")
            if char[2] == "C":
                listChar.append(char)
        f.close()

        for c in listChar:
            pathRoot = []
            word = wn.synsets(c[0])
            depth = min([len(path) for path in word[0].hypernym_paths()])
            word = word[0]
            while depth > 1:
                filter = word.hypernyms()
                word = filter[0]
                depth = depth - 1
                pathRoot.append(filter[0].name())

            flag0 = ":" + str(c[1]) + " :hasCharacteristic :char" + str(c[1]).capitalize() + ".\n" \
                    ":char" + str(c[1]).capitalize() + " rdf:type :Characteristic.\n"
            flag1 = ""
            flag2 = ""
            for p in pathRoot:
                if "color" in p:
                    flag1 = ":" + str(c[1]) + " :hasColor :" + str(c[0]) + ".\n"
                    flag2 = ":" + str(c[0]) + " rdf:type :CharacteristicColor.\n"
                    break
                elif "matter" in p:
                    flag1 = ":" + str(c[1]) + " :hasMaterial :" + str(c[0]) + ".\n"
                    flag2 = ":" + str(c[0]) + " rdf:type :CharacteristicMaterial.\n"
                    break
                else:
                    pass

            g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
            g.write(flag0 + flag1 + flag2)
            g.close()
        return 1