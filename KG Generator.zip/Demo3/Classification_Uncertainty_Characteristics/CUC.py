def Remove(duplicate):
    final = []
    for num in duplicate:
        if num not in final:
            final.append(num)
    return final


def partOf(triplet):### If want to display uncertainty in relations for two object only here needs changes
    g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
    help = ":" + str(triplet[2]) + " :isPartOf :" + str(triplet[0]) + ".\n"
    help1 = ":certainty" + str(triplet[0]).capitalize() + str(triplet[1]) + str(triplet[2]).capitalize() + " rdf:type :Certainty.\n"
    help2 = ":certainty" + str(triplet[0]).capitalize() + str(triplet[1]) + str(triplet[2]).capitalize() + " :listOfObject (:" + str(triplet[0]) + " :" + str(triplet[2]) + ");\n"
    help3 = ":certaintyValue \"" + str(triplet[3]) + "\"^^xsd:double;\n"
    help4 = ":inImage :" + str(triplet[4]) + ".\n"
    g.write(help + help1 + help2 + help3 + help4)
    g.close()

def classify(triplet):
    g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
    help = ":" + str(triplet[0]) + " rdf:type :" + str(triplet[2]).capitalize() + ";\n"
    help1 = ":classificationCertainty \"" + str(triplet[3]) + "\"^^xsd:double;\n"
    help2 = ":isInImage :" + str(triplet[4]) + ".\n"
    g.write(help + help1 + help2)
    g.close()


def characteristic(triplet, listColor, listMaterial, listShape):
    g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
    if triplet[1] == "color":
        help = ":" + str(triplet[0]) + " :hasColor :" + str(triplet[2]) +";\n"
        help1 = ":colorCertainty \"" + str(triplet[3]) + "\"^^xsd:double.\n"
        g.write(help + help1)
        listColor.append(triplet[2])
    elif triplet[1] == "material":
        help = ":" + str(triplet[0]) + " :hasMaterial :" + str(triplet[2]) +";\n"
        help1 = ":materialCertainty \"" + str(triplet[3]) + "\"^^xsd:double.\n"
        g.write(help + help1)
        listMaterial.append(triplet[2])
    elif triplet[1] == "shape":
        help = ":" + str(triplet[0]) + " :hasShape :" + str(triplet[2]) +";\n"
        help1 = ":shapeCertainty \"" + str(triplet[3]) + "\"^^xsd:double.\n"

        g.write(help + help1)
        listShape.append(triplet[2])

    g.close()

    return listColor, listMaterial, listShape




if __name__ == '__main__':
    listTriplet = []
    f = open('cucTest.txt')
    for line in f.readlines():
        listTriplet.append(line.replace("\n", "").split(", "))
    f.close()

    listChar = ["color", "shape", "material"]



    listColor = []
    listMaterial = []
    listShape = []
    for triplet in listTriplet:
        if triplet[1] == "isA":
            classify(triplet)
        elif triplet[1] == "part":
            partOf(triplet)
        elif triplet[1] in listChar:
            listColor, listMaterial, listShape = characteristic(triplet, listColor, listMaterial, listShape)
        else:
            pass

    listPartOf = []###Generalization of PartOf
    for triplet in listTriplet:
        if triplet[1] == "part":
            tri0 = ''.join([i for i in triplet[0] if not i.isdigit()])
            tri0 = tri0.capitalize()
            tri2 = ''.join([i for i in triplet[2] if not i.isdigit()])
            tri2 = tri2.capitalize()
            help = ":" + str(tri0) + " :isPartOf :" + str(tri2) + ".\n"
            listPartOf.append(help)

    listPartOf = Remove(listPartOf)##Finish generalization of partOf
    g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
    for tri in listPartOf:
        g.write(tri)
    g.close()




    listColor = Remove(listColor)
    listMaterial = Remove(listMaterial)
    listShape = Remove(listShape)
    g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
    for color in listColor:
        helpColor = ":" + str(color) + " rdf:type :CharacteristicColor.\n"
        g.write(helpColor)

    for material in listMaterial:
        helpMaterial = ":" + str(material) + " rdf:type :CharacteristicMaterial.\n"
        g.write(helpMaterial)

    for shape in listShape:
        helpShape = ":" + str(shape) + " rdf:type :CharacteristicShape.\n"
        g.write(helpShape)
    g.close()