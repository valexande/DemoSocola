import json
from nltk.corpus import wordnet as wn
import textdistance


def Remove(duplicate):
    final = []
    for num in duplicate:
        if num not in final:
            final.append(num)
    return final

def findSynset():
    with open('somethingJson.json', 'r') as out:
        j = json.loads(out.read())

    found, sentence, missing = [], [], []
    for l in j.items():
        word = wn.synsets(l[1])
        if len(word) > 0:
            found = found + [l[1]]
        else:
            sent = l[1].split(" ")
            mini = []
            for w in sent:
                wordNew = wn.synsets(w)
                if len(wordNew) > 0:
                    mini.append(wordNew[0].name())
                else:
                    continue
            if mini !=[]:
                sentence.append((mini, l[1]))
            else:
                missing.append(l[1])

    return found, sentence, missing

def cleanSentence(sentence):

    sentClean = []
    for li in sentence:
        min = []
        for word in li[0]:
            word = word.replace(".n.", "").replace(".v.", "").replace(".a.", "").replace(".r.", "")
            word = ''.join([i for i in word if not i.isdigit()])
            min.append(word)
        sentClean.append((min, li[1]))

    return sentClean

def findMissing(found, sentence, missing):


    newFound = []
    k = 0
    for m in missing:
        scores = []
        for f in found:
            synonyms = wn.synsets(f)
            for s in synonyms:
                s = s.name().replace(".n.", "").replace(".v.", "").replace(".a.", "").replace(".r.", "")
                s = ''.join([i for i in s if not i.isdigit()])
                v = textdistance.ratcliff_obershelp(str(m), str(s))
                scores.append((m, f, v))
        for se in sentence:
            for ground in se[0]:
                synonyms = wn.synsets(ground)
                for s in synonyms:
                    s = s.name().replace(".n.", "").replace(".v.", "").replace(".a.", "").replace(".r.", "")
                    s = ''.join([i for i in s if not i.isdigit()])
                    v = textdistance.ratcliff_obershelp(str(m), str(s))
                    scores.append((m, se[1], v))

        #scores = Remove(scores)
        scores = sorted(scores, key = lambda x: x[2], reverse=True)
        print(scores[1])
        newFound.append(scores[1])
        k = k + 1
        print(k)

    return newFound


def export(found, sentence, missing):
    f = open("cluster.txt", "a")
    f.write("Found Ones\n")
    for fo in found:
        f.write(str(fo) + "\n")

    f.write("\n\n")
    f.write("Sentence Ones\n")
    for s in sentence:
        try:
            f.write(str(s) + "\n")
        except Exception:
            continue

    f.write("\n\n")
    f.write("Missing Ones\n")
    for m in missing:
        try:
            f.write(str(m) + "\n")
        except Exception:
            continue

if __name__=="__main__":
    found, sentence, missing = findSynset()
    sentence = cleanSentence(sentence)
    missing = findMissing(found, sentence, missing)

    export(found, sentence, missing)
    #print(len(found))
    #print("\n\n\n")
    #print(sentence)
    #print("\n\n\n")
    #print(missing)