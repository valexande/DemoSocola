import requests
from processing import *

class depthBig():



    def __init__(self, objectN, actionN, depth):
        self.objectN = objectN
        self.actionN = actionN
        self.depth = depth

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def myfunc(self, term):
        return 'http://api.conceptnet.io/c/en/' + term + '?offset=0&limit=1000'

    def cn(self, c):
        id = self.myfunc(c)
        respone = requests.get(id)
        objAction = respone.json()

        lst1 = [relation['rel']['@id'] for relation in objAction['edges']]
        lst2 = [relation['@id'] for relation in objAction['edges']]
        lst3 = [relation['weight'] for relation in objAction['edges']]

        return lst1, lst2, lst3

    def getNodes(self):

        helper = []
        for property in self.objectN:
            listPrp = self.objectN[property]
            for e in listPrp:
                for pr in e:
                    for entity in e[pr]:
                        helper.append((entity, [property, pr]))


        NO = []
        for i in range(self.depth):
            helper0 = []
            print(len(helper))
            k = 0
            for e in helper:
                try:
                    data1, data2, data3 = self.cn(e[0])
                    prp = findSimilarity(data2, data1, [e[0]], data3)
                    first = prp.cleaning_entities()
                    second, weights = prp.cleaning_entities2(first[1], first[0])
                    cleaned_weights = prp.grounding(second, weights)
                    for property in cleaned_weights:
                        for entity in cleaned_weights[property]:
                            helper0.append((entity, e[1] + [property]))
                except Exception as t:
                    pass
                break###Remove this afterwards!!!!!!!!
                k += 1
                print(k)
            helper = helper0
            NO.append(helper0)



        helper = []
        for property in self.actionN:
            listPrp = self.actionN[property]
            for e in listPrp:
                for pr in e:
                    for entity in e[pr]:
                        helper.append((entity, [property, pr]))

        NA = []
        for i in range(self.depth):
            print(len(helper))
            k = 0
            helper0 = []
            for e in helper:
                try:
                    data1, data2, data3 = self.cn(e[0])
                    prp = findSimilarity(data2, data1, [e[0]], data3)
                    first = prp.cleaning_entities()
                    second, weights = prp.cleaning_entities2(first[1], first[0])
                    cleaned_weights = prp.grounding(second, weights)
                    for property in cleaned_weights:
                        for entity in cleaned_weights[property]:
                            helper0.append((entity, e[1] + [property]))
                except Exception as t:
                    pass
                break###Remove this afterwards!!!!!!!!
                k += 1
                print(k)
            helper = helper0
            NA.append(helper0)

        N = []
        for i in range(self.depth):
            N.append((NO[i], NA[i]))


        return N
