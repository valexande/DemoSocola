import os, json
from nltk.corpus import wordnet as wn

def findJson(obj, action):
    file = str(obj) + str(action).capitalize() + "Final.json"
    os.chdir("D:\Phd_Projects\Demo\subgraphFinal")
    with open(str(file), 'r') as out:
        j = json.loads(out.read())
        return j

def Remove(duplicate):
    final = []
    for num in duplicate:
        if num not in final:
            final.append(num)
    return final

def findHypernyms(jsonFile, object, action):
    key = list(jsonFile.keys())
    obj = jsonFile[key[0]]
    act = jsonFile[key[1]]
    con = ['abstraction', 'physical_entity', 'thing', 'attribute', 'communication', 'group', 'measure', 'otherworld',
           'psychological_feature', 'relation', 'set', 'causal_agent', 'matter', 'object', 'process', 'substance',
           'thing', 'change', '.v.']
    objNew = {}
    for n in obj:
        contextList = []
        for l in obj[n]:
            if isinstance(l[1], str):
                listWord = l[1].split(" ")##we might have a small sentence
                pathSentence = []
                for w in listWord:
                    pathRoot = []
                    wordΝet = wn.synsets(w)
                    try:
                        depth = min([len(path) for path in wordΝet[0].hypernym_paths()])
                        wordΝet = wordΝet[0]
                        while depth > 1:
                            filter = wordΝet.hypernyms()
                            wordΝet = filter[0]
                            depth = depth - 1
                            pathRoot.append(filter[0].name())
                    except:
                        continue
                    pathSentence.append(pathRoot)##the path root for each small sentence
                pathSentenceFinal = []##take the contect
                for p in pathSentence:
                    for step in p:
                        for c in con:
                            if c in step:
                                pathSentenceFinal.append(p)
                            else:
                                continue
                pathSentenceFinal = Remove(pathSentenceFinal)#we are ready to create the hash with context
                if pathSentenceFinal != []:
                    contextList.append((l[0], l[1]))
            else:
                for entity in l[1]:
                    listWord = entity.split(" ")
                    pathSentence = []
                    for w in listWord:
                        pathRoot = []
                        wordΝet = wn.synsets(w)
                        try:
                            depth = min([len(path) for path in wordΝet[0].hypernym_paths()])
                            wordΝet = wordΝet[0]
                            while depth > 1:
                                filter = wordΝet.hypernyms()
                                wordΝet = filter[0]
                                depth = depth - 1
                                pathRoot.append(filter[0].name())
                        except:
                            continue
                        pathSentence.append(pathRoot)  ##the path root for each small sentence
                    pathSentenceFinal = []##gather the context
                    for p in pathSentence:
                        for step in p:
                            for c in con:
                                if c in step:
                                    pathSentenceFinal.append(p)
                                else:
                                    continue
                    pathSentenceFinal = Remove(pathSentenceFinal)#we are ready to create the hash with context
                    if pathSentenceFinal != []:
                        contextList.append((l[0], entity))## create hash for object
        objNew[n] = contextList


    ##works just fine, try to implement context now
    actNew = {}
    for n in act:
        contextList = []
        for l in act[n]:
            if isinstance(l[1], str):
                listWord = l[1].split(" ")##we might have a small sentence
                pathSentence = []
                for w in listWord:
                    pathRoot = []
                    wordΝet = wn.synsets(w)
                    try:
                        depth = min([len(path) for path in wordΝet[0].hypernym_paths()])
                        wordΝet = wordΝet[0]
                        while depth > 1:
                            filter = wordΝet.hypernyms()
                            wordΝet = filter[0]
                            depth = depth - 1
                            pathRoot.append(filter[0].name())
                    except:
                        continue
                    pathSentence.append(pathRoot)##the path root for each small sentence
                pathSentenceFinal = []##take the contect
                for p in pathSentence:
                    for step in p:
                        for c in con:
                            if c in step:
                                pathSentenceFinal.append(p)
                            else:
                                continue
                pathSentenceFinal = Remove(pathSentenceFinal)# ready to create the hash with context
                if pathSentenceFinal != []:
                    contextList.append((l[0], l[1]))
            else:
                for entity in l[1]:
                    listWord = entity.split(" ")
                    pathSentence = []
                    for w in listWord:
                        pathRoot = []
                        wordΝet = wn.synsets(w)
                        try:
                            depth = min([len(path) for path in wordΝet[0].hypernym_paths()])
                            wordΝet = wordΝet[0]
                            while depth > 1:
                                filter = wordΝet.hypernyms()
                                wordΝet = filter[0]
                                depth = depth - 1
                                pathRoot.append(filter[0].name())
                        except:
                            continue
                        pathSentence.append(pathRoot)  ##the path root for each small sentence
                    pathSentenceFinal = []  ##take the contect
                    for p in pathSentence:
                        for step in p:
                            for c in con:
                                if c in step:
                                    pathSentenceFinal.append(p)
                                else:
                                    continue
                    pathSentenceFinal = Remove(pathSentenceFinal)# we are ready to create the hash with context
                    if pathSentenceFinal != []:
                        contextList.append((l[0], entity))##create the hash for the action
        actNew[n] = contextList
    hashFinal = {}
    hashFinal[str(object)] = objNew
    hashFinal[str(action)] = actNew

    return hashFinal


def export(hashFinal, obj, act):
    os.chdir("D:\PhD_Projects\Demo\subgraphContext")
    name = str(obj) + str(act).capitalize() + "Context.json"
    with open(str(name), 'w') as out:
        json.dump(hashFinal, out)

    return name

if __name__=="__main__":
    print("Give Object Action")
    choice = input()
    choice = choice.split(" ")
    jsonFile = findJson(choice[0], choice[1])
    hashFinal = findHypernyms(jsonFile, choice[0], choice[1])
    nameFinal = export(hashFinal, choice[0], choice[1])
    print("...graph created!")
