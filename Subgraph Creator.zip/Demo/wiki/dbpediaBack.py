import os
import json
from SPARQLWrapper import SPARQLWrapper, JSON
from dbpediaFinal import *


def Remove(duplicate):
    final = []

    for num in duplicate:
        if num not in final:
            final.append(num)
    return final

def spraql(obj, action):

    try:
        sparql_address = SPARQLWrapper("http://dbpedia.org/sparql")
        sparql_address.setQuery("""
                        PREFIX : <http://dbpedia.org/resource/>
                        SELECT ?x ?y WHERE{
                        {:""" + str(obj).capitalize() + """ ?x ?y}
                        UNION {?y ?x :""" + str(obj).capitalize() + """}}
                        """)
        sparql_address.setReturnFormat(JSON)
        resultsObject = sparql_address.query().convert()
        resultsObject = resultsObject['results']['bindings']
    except Exception as e:
        pass

    dbpediaObj = []
    for h in resultsObject:
        try:
            o1 = h['x']['value']
            if "gold" in str(o1):
                o1 = str(o1).split("/gold/")
                o2 = h['y']['value'].split("/resource/")
                dbpediaObj.append((o1[1], o2[1].replace("_", " ")))
            elif "ontology" in str(o1):
                o1 = str(o1).split("/ontology/")
                o2 = h['y']['value'].split("/resource/")
                dbpediaObj.append((o1[1], o2[1].replace("_", " ")))
            elif "property" in str(o1):
                o1 = str(o1).split("/property/")
                o2 = h['y']['value'].split("/resource/")
                dbpediaObj.append((o1[1], o2[1].replace("_", " ")))
            elif "owl#" in str(o1):
                o1 = str(o1).split("owl#")
                o2 = h['y']['value'].split("/resource/")
                dbpediaObj.append((o1[1], o2[1].replace("_", " ")))
        except Exception:
            continue
    try:
        sparql_address = SPARQLWrapper("http://dbpedia.org/sparql")
        sparql_address.setQuery("""
                        PREFIX : <http://dbpedia.org/resource/>
                        SELECT ?x ?y WHERE{
                        {:""" + str(action).capitalize() + """ ?x ?y}
                        UNION {?y ?x :""" + str(action).capitalize() + """}}
                        """)
        sparql_address.setReturnFormat(JSON)
        resultsAction = sparql_address.query().convert()
        resultsAction = resultsAction['results']['bindings']

    except Exception as e:
        pass

    dbpediaAction = []
    for h in resultsAction:
        try:
            a1 = h['x']['value']
            if "ontology" in str(a1):
                a1 = str(a1).split("/ontology/")
                a2 = h['y']['value'].split("/resource/")
                dbpediaAction.append((a1[1], a2[1].replace("_", " ")))
            elif "property" in str(a1):
                a1 = str(a1).split("/property/")
                a2 = h['y']['value'].split("/resource/")
                dbpediaAction.append((a1[1], a2[1].replace("_", " ")))
            elif "owl#" in str(a1):
                a1 = str(a1).split("owl#")
                a2 = h['y']['value'].split("/resource/")
                dbpediaAction.append((a1[1], a2[1].replace("_", " ")))
        except Exception:
            continue

    dbpediaObj = Remove(dbpediaObj)
    dbpediaAction = Remove(dbpediaAction)
    return dbpediaObj, dbpediaAction


def bigger(resultObj, resultAction, depth):
    k = 1
    NO = []
    helper = resultObj
    while k < int(depth):
        helper0 = []
        print(len(helper))
        for e in helper:
            try:
                sparql_address = SPARQLWrapper("http://dbpedia.org/sparql")
                sparql_address.setQuery("""
                                PREFIX : <http://dbpedia.org/resource/>
                                SELECT ?x ?y WHERE{
                                {:""" + str(e[1]).capitalize() + """ ?x ?y}
                                UNION {?y ?x :""" + str(e[1]).capitalize() + """}}
                                """)
                sparql_address.setReturnFormat(JSON)
                results = sparql_address.query().convert()
                results = results['results']['bindings']
            except Exception:
                continue
            for h in results:
                try:
                    a1 = h['x']['value']
                    if "ontology" in str(a1):
                        a1 = str(a1).split("/ontology/")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                    elif "property" in str(a1):
                        a1 = str(a1).split("/property/")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                    elif "owl#" in str(a1):
                        a1 = str(a1).split("owl#")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                except Exception:
                    continue
        helper = helper0
        NO.append(helper0)
        k = k + 1

    t = 1
    NA = []
    hel = resultAction
    while t < int(depth):
        helper0 = []
        print(len(hel))
        for e in hel:
            try:
                sparql_address = SPARQLWrapper("http://dbpedia.org/sparql")
                sparql_address.setQuery("""
                                PREFIX : <http://dbpedia.org/resource/>
                                SELECT ?x ?y WHERE{
                                {:""" + str(e[1]).capitalize() + """ ?x ?y}
                                UNION {?y ?x :""" + str(e[1]).capitalize() + """}}
                                """)
                sparql_address.setReturnFormat(JSON)
                results = sparql_address.query().convert()
                results = results['results']['bindings']
            except Exception:
                continue
            for h in results:
                try:
                    a1 = h['x']['value']
                    if "ontology" in str(a1):
                        a1 = str(a1).split("/ontology/")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                    elif "property" in str(a1):
                        a1 = str(a1).split("/property/")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                    elif "owl#" in str(a1):
                        a1 = str(a1).split("owl#")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                except Exception:
                    continue
        hel = helper0
        NA.append(helper0)
        t = t + 1


    return NO, NA




def clean(resultObj, resultAction, biggerObj, biggerAction, object, action):

    O1 = []
    for obj in resultObj:
        if str(object).lower() != str(obj[1]).lower():
            O1.append(obj)

    A1 = []
    for act in resultAction:
        if str(action).lower() != str(act[1]).lower():
            A1.append(action)

    O2 = []
    for l in biggerObj:
        o2 = []
        for tu in l:
            if str(object).lower() != str(tu[1]).lower():
                o2.append(tu)
        O2.append(o2)

    A2 = []
    for l in biggerAction:
        a2 = []
        for tu in l:
            if str(action).lower() != str(tu[1]).lower():
                a2.append(tu)
        A2.append(a2)

    return O1, A1, O2, A2



def createjson(smallObj, smallAction, biggerObj, biggerAction, object, action):

    wikiObjBigger = {}
    wikiObjBigger['N1'] = smallObj
    for l in range(len(biggerObj)):
        n = "N" + str(l + 2)
        wikiObjBigger[str(n)] = biggerObj[l]


    wikiActionBigger = {}
    wikiActionBigger['N1'] = smallAction
    for l in range(len(biggerAction)):
        n = "N" + str(l + 2)
        wikiActionBigger[str(n)] = biggerAction[l]

    namejson = str(object) + str(action).capitalize() + "Wiki.json"

    hashFinal = {}
    hashFinal[str(object)] = wikiObjBigger
    hashFinal[str(action)] = wikiActionBigger


    return hashFinal, namejson




if __name__ == "__main__":
    print("Give Object Action")
    choice = input()
    choice = choice.split(" ")
    depth = 2
    print("...creating the graph")
    resultObj, resultAction = spraql(choice[0], choice[1])
    biggerObj, biggerAction = bigger(resultObj, resultAction, depth)

    resultObj, resultAction, biggerObj, biggerAction = clean(resultObj, resultAction, biggerObj, biggerAction, choice[0], choice[1])
    jsonWiki, jsonName = createjson(resultObj, resultAction, biggerObj, biggerAction, choice[0], choice[1])
    print("...creating final form")
    finaljson = createFinal(jsonWiki)
    jsonWikiFinal = finaljson.mainCreate()
    print("\n...the graph was created")
