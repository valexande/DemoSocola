import os, json


class createFinal():

    def __init__(self, json):
        self.json = json


    def findPrp(self, jsonFile):
        prpList = [('wikiPageWikiLink', 2), ('birthPlace', 2), ('deathPlace', 2), ('hypernym', 2), ('sameAs', 2), ('wikiPageRedirects', 2), ('e', 2),
                       ('product', 2), ('genre', 2), ('type', 2), ('n', 2), ('a', 2), ('w', 2), ('industry', 2), ('field', 2), ('location', 2), ('religion', 2),
                       ('wikiPageDisambiguates', 2), ('ingredient', 2), ('products', 2), ('materials', 2), ('colour', 2), ('stadium', 2), ('construction', 2), ('fueltype', 2),
                       ('constructionMaterial', 2), ('country', 2), ('arrondissement', 2), ('material', 2), ('differentFrom', 2), ('occupation', 2), ('place', 2), ('knownFor', 2),
                       ('chassis', 2), ('architecturalStyle', 2), ('genus', 2), ('title', 2), ('publisher', 2), ('academicDiscipline', 2), ('surface', 2), ('city', 2),
                       ('region', 2), ('colors', 2), ('thFuelPrimary', 2), ('input', 2), ('format', 2), ('headAlloy', 2), ('carbody', 2),
                       ('service', 2), ('o', 2), ('periph', 2), ('movement', 2), ('hometown', 2), ('mainInterest', 2), ('venue', 2), ('ground', 2), ('s', 2),
                       ('nonFictionSubject', 2), ('division', 2), ('composition', 2), ('countryAdminDivisions', 2), ('c', 2), ('isPartOf', 2), ('artist', 2), ('f', 2),
                       ('headquarter', 2), ('associatedBand', 2), ('associatedMusicalArtist', 2), ('language', 2), ('instrument', 2), ('religiousAffiliation', 2),
                       ('capital', 2), ('geology', 2), ('blockAlloy', 2), ('prilithology', 2), ('otherlithology', 2), ('structuralSystem', 2), ('builder', 2), ('producer', 2),
                       ('subdivisionType', 2), ('regionServed', 2), ('populationPlace', 2), ('establishedEvent', 2), ('residence', 2), ('postTown', 2), ('leader', 2),
                       ('position', 2), ('literaryGenre', 2), ('manufacturer', 1), ('recordedIn', 1), ('recordLabel', 1), ('similar', 1), ('restingPlace', 1),
                       ('activitySector', 1), ('subsequentWork', 1), ('influencedBy', 1), ('locationCity', 1), ('hasVariant', 1), ('class', 1), ('previousWork', 1),
                       ('shipSensors', 1), ('caption', 1), ('home', 1), ('district', 1), ('aux', 1), ('spokenIn', 1), ('label', 1), ('author', 1), ('connectivity', 1),
                       ('profession', 1), ('localite', 1), ('keyPerson', 1), ('style', 1), ('neighboringMunicipality', 1),
                       ('broadcastArea', 1), ('garrison', 1), ('category', 1), ('timeZone', 1), ('foundation', 1), ('t', 1), ('cause', 1), ('r1Surface', 1), ('p', 1), ('focus', 1),
                       ('education', 1), ('routeEnd', 1), ('colours', 1), ('veneratedIn', 1), ('governmentType', 1), ('team', 1), ('nationality', 1), ('h1Surface', 1), ('stylisticOrigin', 1),
                       ('ideology', 1), ('operatingSystem', 1), ('rev', 1), ('lyrics', 1), ('st', 1), ('ethnicity', 1), ('serviceType',1), ('tree', 1), ('rock', 1), ('data', 1), ('municipality', 1),
                       ('currency', 1), ('regionalLanguage', 1), ('locationCountry', 1), ('order', 1), ('soil', 1), ('bodyStyle', 1), ('locatedInArea', 1), ('headquarters', 1), ('majorShrine', 1),
                       ('territory', 1), ('ethnicGroup', 1), ('equipment', 1), ('programmeFormat', 1), ('related', 1), ('nearestCity', 1), ('routeStart', 1), ('mainInterests', 1), ('era', 1),
                       ('classification', 1), ('formula', 1), ('fields', 1), ('officialLanguage', 1), ('seat', 1), ('leaderName', 1), ('bandMember', 1), ('architectureStyle', 1), ('blankNameSec', 1),
                       ('campus', 1), ('languages', 1), ('family', 1), ('teams', 1), ('paperType', 1)]
        k = list(jsonFile.keys())
        obj = jsonFile[str(k[0])]
        action = jsonFile[str(k[1])]

        pathO = {}
        for n in obj:
            pathObj = []
            for l in obj[n]:
                if isinstance(l[0], str):
                    pathObj.append(l)
                else:
                    flag = 0
                    for p in l[0]:
                        val = len(l[0]) - l[0][::-1].index(p)
                        for prp in prpList:
                            if p == prp[0]:
                                if int(val) <= prp[1]:
                                    flag = 0
                                else:
                                    flag = 1
                                    break
                    if flag == 0:
                        pathObj.append(l)
            pathO[n] = pathObj

        pathA = {}
        for n in action:
            pathAction = []
            for l in action[n]:
                if isinstance(l, str):
                    pathAction.append(l)
                else:
                    flag = 0
                    for p in l[0]:
                        val = len(l[0]) - l[0][::-1].index(p)
                        for prp in prpList:
                            if p == prp[0]:
                                if int(val) <= prp[1]:
                                    flag = 0
                                else:
                                    flag = 1
                                    break
                    if flag == 0:
                        pathAction.append(l)
            pathA[n] = pathAction

        hashFinal = {}
        hashFinal[str(k[0])] = pathO
        hashFinal[str(k[1])] = pathA

        return hashFinal

    def export(self, hashFinal, object, action):
        os.chdir("D:\Phd_Projects\Demo\subgraphDBpedia")
        name = str(object) + str(action).capitalize() + "Wiki.json"
        with open(str(name), 'w') as out:
            json.dump(hashFinal, out)

        return name

    def mainCreate(self):

        choice = list(self.json.keys())
        hashFinal = self.findPrp(self.json)
        nameHash = self.export(hashFinal, choice[0], choice[1])
        return hashFinal