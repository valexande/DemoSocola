import os, json
from nltk.corpus import wordnet as wn


class cOn():
    def __init__(self, jsonFile):
        self.jsonFile = jsonFile

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def findHypernymsWiki(self):
        key = list(self.jsonFile.keys())
        obj = self.jsonFile[key[0]]
        act = self.jsonFile[key[1]]
        con = ['abstraction', 'physical_entity', 'thing', 'attribute', 'communication', 'group', 'measure', 'otherworld',
               'psychological_feature', 'relation', 'set', 'causal_agent', 'matter', 'object', 'process', 'substance',
               'thing', 'change', '.v.']
        objNew = {}
        for n in obj:
            contextList = []
            for l in obj[n]:
                if isinstance(l[1], str):
                    listWord = l[1].split(" ")##we might have a small sentence
                    pathSentence = []
                    for w in listWord:
                        pathRoot = []
                        wordΝet = wn.synsets(w)
                        try:
                            depth = min([len(path) for path in wordΝet[0].hypernym_paths()])
                            wordΝet = wordΝet[0]
                            while depth > 1:
                                filter = wordΝet.hypernyms()
                                wordΝet = filter[0]
                                depth = depth - 1
                                pathRoot.append(filter[0].name())
                        except:
                            continue
                        pathSentence.append(pathRoot)##the path root for each small sentence
                    pathSentenceFinal = []##take the contect
                    for p in pathSentence:
                        for step in p:
                            for c in con:
                                if c in step:
                                    pathSentenceFinal.append(p)
                                else:
                                    continue
                    pathSentenceFinal = self.Remove(pathSentenceFinal)#we are ready to create the hash with context
                    if pathSentenceFinal != []:
                        contextList.append((l[0], l[1]))
                else:
                    for entity in l[1]:
                        listWord = entity.split(" ")
                        pathSentence = []
                        for w in listWord:
                            pathRoot = []
                            wordΝet = wn.synsets(w)
                            try:
                                depth = min([len(path) for path in wordΝet[0].hypernym_paths()])
                                wordΝet = wordΝet[0]
                                while depth > 1:
                                    filter = wordΝet.hypernyms()
                                    wordΝet = filter[0]
                                    depth = depth - 1
                                    pathRoot.append(filter[0].name())
                            except:
                                continue
                            pathSentence.append(pathRoot)  ##the path root for each small sentence
                        pathSentenceFinal = []##gather the context
                        for p in pathSentence:
                            for step in p:
                                for c in con:
                                    if c in step:
                                        pathSentenceFinal.append(p)
                                    else:
                                        continue
                        pathSentenceFinal = self.Remove(pathSentenceFinal)#we are ready to create the hash with context
                        if pathSentenceFinal != []:
                            contextList.append((l[0], entity))## create hash for object
            objNew[n] = contextList


        ##works just fine, try to implement context now
        actNew = {}
        for n in act:
            contextList = []
            for l in act[n]:
                if isinstance(l[1], str):
                    listWord = l[1].split(" ")##we might have a small sentence
                    pathSentence = []
                    for w in listWord:
                        pathRoot = []
                        wordΝet = wn.synsets(w)
                        try:
                            depth = min([len(path) for path in wordΝet[0].hypernym_paths()])
                            wordΝet = wordΝet[0]
                            while depth > 1:
                                filter = wordΝet.hypernyms()
                                wordΝet = filter[0]
                                depth = depth - 1
                                pathRoot.append(filter[0].name())
                        except:
                            continue
                        pathSentence.append(pathRoot)##the path root for each small sentence
                    pathSentenceFinal = []##take the contect
                    for p in pathSentence:
                        for step in p:
                            for c in con:
                                if c in step:
                                    pathSentenceFinal.append(p)
                                else:
                                    continue
                    pathSentenceFinal = self.Remove(pathSentenceFinal)# ready to create the hash with context
                    if pathSentenceFinal != []:
                        contextList.append((l[0], l[1]))
                else:
                    for entity in l[1]:
                        listWord = entity.split(" ")
                        pathSentence = []
                        for w in listWord:
                            pathRoot = []
                            wordΝet = wn.synsets(w)
                            try:
                                depth = min([len(path) for path in wordΝet[0].hypernym_paths()])
                                wordΝet = wordΝet[0]
                                while depth > 1:
                                    filter = wordΝet.hypernyms()
                                    wordΝet = filter[0]
                                    depth = depth - 1
                                    pathRoot.append(filter[0].name())
                            except:
                                continue
                            pathSentence.append(pathRoot)  ##the path root for each small sentence
                        pathSentenceFinal = []  ##take the contect
                        for p in pathSentence:
                            for step in p:
                                for c in con:
                                    if c in step:
                                        pathSentenceFinal.append(p)
                                    else:
                                        continue
                        pathSentenceFinal = self.Remove(pathSentenceFinal)# we are ready to create the hash with context
                        if pathSentenceFinal != []:
                            contextList.append((l[0], entity))##create the hash for the action
            actNew[n] = contextList
        hashFinal = {}
        hashFinal[str(key[0])] = objNew
        hashFinal[str(key[1])] = actNew

        return hashFinal