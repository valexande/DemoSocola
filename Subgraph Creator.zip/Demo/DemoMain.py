import requests
from processing import *
from depthBigger import *
from depthProcess import *

def Remove(duplicate):
    final = []
    for num in duplicate:
        if num not in final:
            final.append(num)
    return final

def myfunc(term):
    return 'http://api.conceptnet.io/c/en/' + term + '?offset=0&limit=1000'


def cn(c):

    id = myfunc(c)
    respone = requests.get(id)
    objAction = respone.json()


    lst1 = [relation['rel']['@id'] for relation in objAction['edges']]
    lst2 = [relation['@id'] for relation in objAction['edges']]
    lst3 = [relation['weight'] for relation in objAction['edges']]

    return lst1, lst2, lst3


def smallCleaning(weightsAction):
    visited = set()
    Output = []
    for a, b in weightsAction:
        if not a in visited:
            visited.add(a)
            Output.append((a, b))
    return Output


def duplicates(object, action):
    for property in action:
        action[property] = Remove(action[property])
    for property in object:
        object[property] = Remove(object[property])

    return object, action


def depthN2(N1, object, action, depth):

    N2 = []
    help0N2 = {}
    for property in N1[0]:
        help2 = []
        k = 0
        print(len(N1[0][property]))
        for entity in N1[0][property]:
            try:
                data1, data2, data3 = cn(entity)
                prp = findSimilarity(data2, data1, [entity], data3)
                first = prp.cleaning_entities()
                second, weights = prp.cleaning_entities2(first[1], first[0])
                cleaned_weights = prp.grounding(second, weights)
                help2.append(cleaned_weights)
            except Exception as e:
                pass
            k += 1
            print(k)
        help0N2[property] = help2
    N2.append(help0N2)

    help1N2 = {}
    for property in N1[1]:
        help2 = []
        print(len(N1[1][property]))
        k = 0
        for entity in N1[1][property]:
            try:
                data1, data2, data3 = cn(entity)
                prp = findSimilarity(data2, data1, [entity], data3)
                first = prp.cleaning_entities()
                second, weights = prp.cleaning_entities2(first[1], first[0])
                cleaned_weights = prp.grounding(second, weights)
                help2.append(cleaned_weights)
            except Exception as e:
                pass
            k += 1
            print(k)
        help1N2[property] = help2
    N2.append(help1N2)

    if depth > 0:
        print("Hi")
        N = depthBig(N2[0], N2[1], depth)
        deep = N.getNodes()
        prp = process(N2[0], N2[1])
        N2[0], N2[1] = prp.unify()
        prp.exportBigger(N1, N2, object, action, deep)
        exit()


    prp = process(N2[0], N2[1])
    N2[0], N2[1] = prp.unify()
    prp.export(N1, N2, object, action)
    return N2


if __name__ == "__main__":
    print("Give me an object and an action: Object Action")
    choice = input()
    choice = choice.split(" ")


    print("Give me depth")
    depth = input()
    depth = int(depth) - 2
    print("search...")
    N1 = []
    for c in choice:
        data1, data2, data3 = cn(c)
        prp = findSimilarity(data2, data1, [c], data3)
        first = prp.cleaning_entities()
        second, weights = prp.cleaning_entities2(first[1], first[0])
        cleaned_weights = prp.grounding(second, weights)
        N1.append(cleaned_weights)

    N1[0], N1[1] = duplicates(N1[0], N1[1])
    N2 = depthN2(N1, choice[0], choice[1], depth)
    exit()