import os, json, requests
from os import listdir
from processing import *
from os.path import isfile, join


class findJson():

    def __init__(self, object, action):
        self.object = object
        self.action = action

    def myfunc(self, term):
        return 'http://api.conceptnet.io/c/en/' + term + '?offset=0&limit=1000'

    def cn(self, c):
        id = self.myfunc(c)
        respone = requests.get(id)
        objAction = respone.json()

        lst1 = [relation['rel']['@id'] for relation in objAction['edges']]
        lst2 = [relation['@id'] for relation in objAction['edges']]
        lst3 = [relation['weight'] for relation in objAction['edges']]

        return lst1, lst2, lst3

    def findFile(self):
        onlyfiles = [f for f in listdir("D:\PhD_Projects\Demo\subgraph")
                     if isfile(join("D:\PhD_Projects\Demo\subgraph", f))]

        f =  ""
        for file in onlyfiles:
            if self.object in str(file) and self.action.capitalize() in str(file):
                f = (file, "both")
                break

        if f == "":
            for file in onlyfiles:
                if self.object in str(file):
                    f = (file, "object")
                    break
                if self.action.capitalize() in str(file):
                    f = (file, "action")
                    break
        if f == "":
            f = ("None", "None")

        return f


    def getJson(self, file):

        os.chdir("D:\Phd_Projects\Demo2\subgraph")
        with open(str(file[0]), 'r') as out:
            j = json.loads(out.read())

        if file[1] == "object":
            hashO = j[str(self.object)]
            return hashO, self.object
        if file[1] == "action":
            hashA = j[str(self.action)]
            return hashA, self.action




    def N2Object(self, Ahash, ON1):
        N2 = {}
        help1N2 = {}
        for property in ON1:
            help2 = []
            print(len(ON1[property]))
            k = 0
            for entity in ON1[property]:
                try:
                    data1, data2, data3 = self.cn(entity)
                    prp = findSimilarity(data2, data1, [entity], data3)
                    first = prp.cleaning_entities()
                    second, weights = prp.cleaning_entities2(first[1], first[0])
                    cleaned_weights = prp.grounding(second, weights)
                    help2.append(cleaned_weights)
                except Exception as e:
                    continue
                k += 1
                print(k)
            help1N2[property] = help2
        N = {}
        N2['N1'] = ON1
        N2['N2'] = help1N2
        N[str(self.object)] = Ahash
        N[str(self.action)] = N2

        name = str(self.object) + str(self.action).capitalize() + ".json"

        os.chdir("D:\Phd_Projects\Demo\subgraph")
        with open(str(name), 'w') as out:
            json.dump(N, out)

    def N2Action(self, Ohash, AN1):
        N2 = {}
        help1N2 = {}
        for property in AN1:
            help2 = []
            print(len(AN1[property]))
            k = 0
            for entity in AN1[property]:
                try:
                    data1, data2, data3 = self.cn(entity)
                    prp = findSimilarity(data2, data1, [entity], data3)
                    first = prp.cleaning_entities()
                    second, weights = prp.cleaning_entities2(first[1], first[0])
                    cleaned_weights = prp.grounding(second, weights)
                    help2.append(cleaned_weights)
                except Exception as e:
                    continue
                k += 1
                print(k)
            help1N2[property] = help2
        N = {}
        N2['N1'] = AN1
        N2['N2'] = help1N2
        N[str(self.object)] = Ohash
        N[str(self.action)] = N2

        name = str(self.object) + str(self.action).capitalize() + ".json"

        os.chdir("D:\Phd_Projects\Demo\subgraph")
        with open(str(name), 'w') as out:
            json.dump(N, out)
