import os
import json
from SPARQLWrapper import SPARQLWrapper, JSON


def Remove(duplicate):
    final = []

    for num in duplicate:
        if num not in final:
            final.append(num)
    return final

def spraql(obj, action):

    try:
        sparql_address = SPARQLWrapper("http://dbpedia.org/sparql")
        sparql_address.setQuery("""
                        PREFIX : <http://dbpedia.org/resource/>
                        SELECT ?x ?y WHERE{
                        {:""" + str(obj).capitalize() + """ ?x ?y}
                        UNION {?y ?x :""" + str(obj).capitalize() + """}}
                        """)
        sparql_address.setReturnFormat(JSON)
        resultsObject = sparql_address.query().convert()
        resultsObject = resultsObject['results']['bindings']
    except Exception as e:
        pass

    dbpediaObj = []
    for h in resultsObject:
        try:
            o1 = h['x']['value']
            if "gold" in str(o1):
                o1 = str(o1).split("/gold/")
                o2 = h['y']['value'].split("/resource/")
                dbpediaObj.append((o1[1], o2[1].replace("_", " ")))
            elif "ontology" in str(o1):
                o1 = str(o1).split("/ontology/")
                o2 = h['y']['value'].split("/resource/")
                dbpediaObj.append((o1[1], o2[1].replace("_", " ")))
            elif "property" in str(o1):
                o1 = str(o1).split("/property/")
                o2 = h['y']['value'].split("/resource/")
                dbpediaObj.append((o1[1], o2[1].replace("_", " ")))
            elif "owl#" in str(o1):
                o1 = str(o1).split("owl#")
                o2 = h['y']['value'].split("/resource/")
                dbpediaObj.append((o1[1], o2[1].replace("_", " ")))
        except Exception:
            continue
    try:
        sparql_address = SPARQLWrapper("http://dbpedia.org/sparql")
        sparql_address.setQuery("""
                        PREFIX : <http://dbpedia.org/resource/>
                        SELECT ?x ?y WHERE{
                        {:""" + str(action).capitalize() + """ ?x ?y}
                        UNION {?y ?x :""" + str(action).capitalize() + """}}
                        """)
        sparql_address.setReturnFormat(JSON)
        resultsAction = sparql_address.query().convert()
        resultsAction = resultsAction['results']['bindings']

    except Exception as e:
        pass

    dbpediaAction = []
    for h in resultsAction:
        try:
            a1 = h['x']['value']
            if "ontology" in str(a1):
                a1 = str(a1).split("/ontology/")
                a2 = h['y']['value'].split("/resource/")
                dbpediaAction.append((a1[1], a2[1].replace("_", " ")))
            elif "property" in str(a1):
                a1 = str(a1).split("/property/")
                a2 = h['y']['value'].split("/resource/")
                dbpediaAction.append((a1[1], a2[1].replace("_", " ")))
            elif "owl#" in str(a1):
                a1 = str(a1).split("owl#")
                a2 = h['y']['value'].split("/resource/")
                dbpediaAction.append((a1[1], a2[1].replace("_", " ")))
        except Exception:
            continue

    dbpediaObj = Remove(dbpediaObj)
    dbpediaAction = Remove(dbpediaAction)
    return dbpediaObj, dbpediaAction


def bigger(resultObj, resultAction, depth):
    k = 1
    NO = []
    helper = resultObj
    while k < int(depth):
        helper0 = []
        print(len(helper))
        for e in helper:
            try:
                sparql_address = SPARQLWrapper("http://dbpedia.org/sparql")
                sparql_address.setQuery("""
                                PREFIX : <http://dbpedia.org/resource/>
                                SELECT ?x ?y WHERE{
                                {:""" + str(e[1]).capitalize() + """ ?x ?y}
                                UNION {?y ?x :""" + str(e[1]).capitalize() + """}}
                                """)
                sparql_address.setReturnFormat(JSON)
                results = sparql_address.query().convert()
                results = results['results']['bindings']
            except Exception:
                continue
            for h in results:
                try:
                    a1 = h['x']['value']
                    if "ontology" in str(a1):
                        a1 = str(a1).split("/ontology/")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                    elif "property" in str(a1):
                        a1 = str(a1).split("/property/")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                    elif "owl#" in str(a1):
                        a1 = str(a1).split("owl#")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                except Exception:
                    continue
        helper = helper0
        NO.append(helper0)
        k = k + 1

    t = 1
    NA = []
    hel = resultAction
    while t < int(depth):
        helper0 = []
        print(len(hel))
        for e in hel:
            try:
                sparql_address = SPARQLWrapper("http://dbpedia.org/sparql")
                sparql_address.setQuery("""
                                PREFIX : <http://dbpedia.org/resource/>
                                SELECT ?x ?y WHERE{
                                {:""" + str(e[1]).capitalize() + """ ?x ?y}
                                UNION {?y ?x :""" + str(e[1]).capitalize() + """}}
                                """)
                sparql_address.setReturnFormat(JSON)
                results = sparql_address.query().convert()
                results = results['results']['bindings']
            except Exception:
                continue
            for h in results:
                try:
                    a1 = h['x']['value']
                    if "ontology" in str(a1):
                        a1 = str(a1).split("/ontology/")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                    elif "property" in str(a1):
                        a1 = str(a1).split("/property/")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                    elif "owl#" in str(a1):
                        a1 = str(a1).split("owl#")
                        a2 = h['y']['value'].split("/resource/")
                        helper0.append(([e[0]] + [a1[1]], a2[1].replace("_", " ")))
                except Exception:
                    continue
        hel = helper0
        NA.append(helper0)
        t = t + 1

    return NO, NA




def clean(resultObj, resultAction, biggerObj, biggerAction, object, action):

    O1 = []
    for obj in resultObj:
        if str(object).lower() != str(obj[1]).lower():
            O1.append(obj)

    A1 = []
    for action in resultAction:
        if str(action).lower() in str(action[1]).lower():
            A1.append(action)

    O2 = []
    for l in biggerObj:
        for tu in l:
            if str(object).lower() != str(tu[1]).lower():
                O2.append(tu)

    A2 = []
    for l in biggerAction:
        for tu in l:
            if str(action).lower() != str(tu[1]).lower():
                A2.append(tu)

    return O1, A1, O2, A2


def createjson(resultObj, resultAction, object, action):
    hashWikiObj = {}
    for tu in resultObj:
        if hashWikiObj.get(tu[0]) == None:
            hashWikiObj.setdefault(tu[0], []).append(tu[1])
        else:
            hashWikiObj[tu[0]].append(tu[1])



    hashWikiAction = {}
    for tu in resultAction:
        if hashWikiAction.get(tu[0]) == None:
            hashWikiAction.setdefault(tu[0], []).append(tu[1])
        else:
            hashWikiAction[tu[0]].append(tu[1])


    namejson = str(object) + str(action).capitalize() + "Wiki1.json"

"""
    os.chdir("D:\Phd_Projects\Demo\subgraphDBpedia")
    with open(str(namejson), 'w') as out:
        json.dump(hashWiki, out)

    return hashWiki, namejson
"""




if __name__ == "__main__":
    print("Give Object Action")
    choice = input()
    choice = choice.split(" ")
    depth = 2
    resultObj, resultAction = spraql(choice[0], choice[1])
    biggerObj, biggerAction = bigger(resultObj, resultAction, depth)

    resultObj, resultAction, biggerObj, biggerAction = clean(resultObj, resultAction, biggerObj, biggerAction, choice[0], choice[1])

    print(biggerAction)
    """
    jsonWiki, jsonName = createjson(resultObj, resultAction, choice[0], choice[1])
    print(jsonWiki)
    print("\n...the graph was created")
    """