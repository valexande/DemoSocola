import json
from nltk.corpus import wordnet as wn
import os

class mainParser():

    def __init__(self, json, object, action):
        self.json = json
        self.object = object
        self.action = action

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final


    def common(self):
        obj = self.json[str(self.object)]
        action = self.json[str(self.action)]

        O = []
        for n in obj:
            for t in obj[n]:
                if str(t[1]) != str(self.object):
                    O = O + [t[1]]

        O = self.Remove(O)

        A = []
        for n in action:
            for t in action[n]:
                if str(t[1]) != str(self.action):
                    A = A + [t[1]]
        A = self.Remove(A)

        lenOb = len(O)
        lenA = len(A)
        co1 = list(set(O).intersection(A))
        lenC = len(co1)
        value = lenC/(lenA + lenOb)

        print("\nCommon nodes similarity: " + str(value))

        return co1, O, A, lenC, value


    def wup(self):

        try:
            syn1 = wn.synsets(self.object)[0]
            syn2 = wn.synsets(self.action)[0]
            wUp = syn1.wup_similarity(syn2)
            print("WUP similarity: " + str(wUp))
            return wUp
        except Exception:
            return 0


    def path(self, C):

        object = self.json[str(self.object)]
        action = self.json[str(self.action)]
        C = self.Remove(C)

        pathO = []
        for c in C:
            for n in object:
                for t in object[n]:
                    if c == t[1]:
                        pathO.append((t[0], c))
        pathO = self.Remove(pathO)

        pathA = []
        for c in C:
            for n in action:
                for t in action[n]:
                    if c == t[1]:
                        pathA.append((t[0], c))
        pathA = self.Remove(pathA)

        pO = []
        for o in pathO:
            for a in pathA:
                if o[1] == a[1]:
                    if isinstance(a[0], str) and isinstance(o[0], str):
                        t = [o[0]] + [a[0]]
                    elif isinstance(o[0], str):
                        t = [o[0]] + a[0]
                    elif isinstance(a[0], str):
                        t = o[0] + [a[0]]
                    else:
                        t = o[0] + a[0]
                    pO.append((t, o[1]))
        pO = self.Remove(pO)

        pA = []
        for a in pathA:
            for o in pathO:
                if a[1] == o[1]:
                    if isinstance(o[1], str) and isinstance(a[1], str):
                        t = [a[0]] + [o[0]]
                    elif isinstance(o[1], str):
                        t = a[0] + [o[0]]
                    elif isinstance(a[1], str):
                        t = [a[0]] + [o[0]]
                    else:
                        t = a[0] + o[0]
                    pA.append((t, a[1]))
        pA = self.Remove(pA)


        le = len(pO) + len(pA)

        lO = 0
        for n in object:
            lO = lO + len(object[n])

        lA = 0
        for n in action:
            lA = lA + len(action[n])

        lTotal = lO + lA

        valuePath = float(le/lTotal)
        print("There are " + str(len(pO) + len(pA)) + " common paths in total, which is a percentage of the"
                                                      " total paths " + str(valuePath))

        return pO, pA, valuePath, le



    def pathPattern(self, pO, pA, le, POS):

        pattern = []
        if POS == "OA":
            pattern = [("['/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 10418),
             ("['/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 2768),
             ("['/r/AtLocation', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 1627),
             ("['/r/RelatedTo', '/r/RelatedTo', '/r/AtLocation', '/r/RelatedTo']", 1627),
             ("['/r/RelatedTo', '/r/IsA', '/r/RelatedTo', '/r/IsA']", 1550)]
        elif POS == "S":
            pattern = [("['/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 8462),
             ("['/r/AtLocation', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 2123),
             ("['/r/RelatedTo', '/r/RelatedTo', '/r/AtLocation', '/r/RelatedTo']", 2123),
             ("['/r/AtLocation', '/r/AtLocation', '/r/RelatedTo', '/r/RelatedTo']", 944),
             ("['/r/RelatedTo', '/r/RelatedTo', '/r/AtLocation', '/r/AtLocation']", 944)]
        elif POS == "SW" or POS == "OAW":
            print("Give number of differnt patterns")
            pat = int(input())
            k = 1
            for p in range(pat):
                print("Give me pattern " + str(k) + " in the form: property1 property2 ... propertyN")
                helpPattern = input()
                helpPattern = helpPattern.split(" ")
                pattern.append((helpPattern, 0))
                k = k + 1

        PATH = pO + pA
        counter = 0
        for p in pattern:
            for path in PATH:
                if str(p[0]) == str(path[0]):
                    counter = counter + 1
        valuePattern = float(counter/le)

        print("The value based on path patterns is: " + str(valuePattern))
        if "W" in POS:
            POS = POS.replace("W", "")


        return valuePattern, POS


    def infer(self, valueCommon, valueWUP, valuePath, valuePattern, POS):

        if valueWUP == None:
            valueWUP = 0##if none wordnet could not find one of the two words
            ##but is two strict to consider them zero, we use labels from the englidh language
            ##which were not found in a database

        weight = 2*valueWUP + 1.75*valuePath + 1.5*valuePattern + valueCommon

        print("\n" + str(weight))
        if weight > 0.5:
            print("\nThe two graphs ARE related adequately")
            os.chdir("D:/PhD_Projects/Unification_of_Components/kgInfo")
            f = open("objPS.txt", "a")
            help = str(self.action) + ", " + str(self.object) + ", " + str(POS) + "\n"
            f.write(help)
            f.close()
        else:
            print("\nThe two graphs are NOT adequately related")