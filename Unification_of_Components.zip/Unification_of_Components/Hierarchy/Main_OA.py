from objectClassification import *
from actionClassification import *


if __name__=="__main__":
    obj = objectHierarchy()
    flagObj = obj.classObject()
    action = actionHierarchy()
    flagAction = action.classAction()