from objPurposeState import *


if __name__=="__main__":
    ps = objPS()
    actionFlag = ps.performRelation()
    stateFlag = ps.stateRelation()