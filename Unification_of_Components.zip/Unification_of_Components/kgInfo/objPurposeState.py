import os
from nltk.corpus import wordnet as wn

class objPS():

    def __init__(self):
        pass

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def performRelation(self):

        f = open("objPS.txt", "r")
        listPurpose = []
        for line in f.readlines():
            listPurpose.append(line.replace("\n", "").split(", "))
        f.close()

        g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
        help = ""
        for purpose in listPurpose:
            if purpose[2] == "OA":
                help = ":" + str(purpose[0]).capitalize() + " :performedBy :" + str(purpose[1]).capitalize() + ".\n "
                g.write(help)
        g.close()

        return 1

    def stateRelation(self):

        f = open("objPS.txt", "r")
        listState = []
        for line in f.readlines():
            listState.append(line.replace("\n", "").split(", "))
        f.close()

        g = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")
        for state in listState:
            if state[2] == "S":
                help = ":" + str(state[1]).capitalize() + " :inState :" + str(state[0]).capitalize() + ".\n"
                g.write(help)

        return 1